group 'consul' do
  gid 1500
  action :create
end

user 'consul' do
  uid 1500
  gid 1500
  home '/home/consul'
  shell '/sbin/nologin'
  action :create
end

directory '/var/lib/consul/install' do
  owner 'consul'
  group 'consul'
  recursive true
  mode '0755'
  action :create
end

execute 'name' do
  command 'chown -R consul. /var/lib/consul'
  action :run
end

execute 'remove_dir_content' do
  command 'rm -rf /var/lib/consul/install/*'
  action :run
end

consul_zip_file = 'consul_0.6.4_linux_amd64.zip'

execute 'unzip_consul' do
  command "unzip #{consul_zip_file}"
  cwd '/var/lib/consul/install/'
  action :nothing
  notifies :run, 'execute[move_consul_to_bin]', :delayed
end

execute 'move_consul_to_bin' do
  command 'mv /var/lib/consul/install/consul /usr/local/bin/consul'
  action :nothing
end

remote_file "/var/lib/consul/install/#{consul_zip_file}" do
  source "https://releases.hashicorp.com/consul/0.6.4/#{consul_zip_file}"
  owner 'root'
  group 'root'
  mode '0755'
  action :create
  notifies :run, 'execute[unzip_consul]', :immediately
end


