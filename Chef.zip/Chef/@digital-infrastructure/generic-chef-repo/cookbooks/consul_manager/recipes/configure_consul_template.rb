template '/usr/lib/systemd/system/consul-template.service' do
  source 'usr/lib/systemd/system/consul-template.service.erb'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

template '/etc/sysconfig/consul-template' do
  source 'etc/sysconfig/consul-template.erb'
  owner 'root'
  group 'root'
  mode '0644'
  variables(
    ip_addr: node['ipaddress']
  )
  action :create
end

execute 'systemctl_reload' do
  command 'systemctl daemon-reload'
  action :run
end
