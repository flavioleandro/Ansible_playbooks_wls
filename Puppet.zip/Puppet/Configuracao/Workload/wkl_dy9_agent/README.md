# wkl_dy9_agent

1. [Descrição](#description)
2. [Setup](#setup)
    * [O que o modulo afeta](#o-que-wkl_dy9_agent-afeta)
    * [Requisitos](#requisitos)
    * [Iniciando](#basico-wkl_dy9_agent)
3. [Exemplos](#exemplos)
4. [Limitações](#limitações)

## Description

Esse modulo instala e configura o agente do AppDynamics, embarcando os argumentos do AppDynamics no JVMARGS da aplicação.

## Setup

### O que wkl_dy9_agent afeta

Arquivos de configuração e diretorios (criados pelo modulo)

* /opt/AppDynamics/*
* /opt/AppDynamics/MachineAgent/conf/controller-info.xml (arquivo de configuração gerenciado pelo modulo)
* Path absoluto do script do serviço da aplicação, alterando o JVMARGS

### Requisitos 

Modulo archive
Modulo systemd

### Basico wkl_dy9_agent

Para instalar o agent do AppDynamics, declare a classe 'wkl_dy9_agent'  e passe os seguintes parametros:

      machine_path        = Sigla do ambiente a ser monitorado, String;
      java_memory         = Memoria do Java, String;
      service_path        = Path absoluto do script do serviço da aplicação, String;
      application_name    = Nome do microserviço que será monitorado, String;
      tier_name           = Nome do microserviço que será monitorado, String; *
      access_key          = Chave de monitoração do AppDynamics, String;
      prefix              = Nome do microserviço que será monitorado, String;
      application_user    = Usuário do microserviço que será monitorado, String;
      install_appdynamics = Parametro boleano que verifica se o AppDynamics será monitorado, aceita 'True' e 'False'
    
Para mais detalhes, veja a documentação no Confluence:
|| Pendente ||

## Exemplos

Situação 1:
Monitorar o microserviço do Customer do WT:

``` puppet
class wkl_xpto {

  class { 'wkl_dy9_agent':
      machine_path        => 'WT|',
      java_memory         => '-Xms256m -Xmx2048m -XX:PermSize=128M -XX:MaxPermSize=256M',
      service_path        => '/opt/WT/microservice/customer/customer.sh',
      application_name    => 'White_Label',
      tier_name           => 'customer',
      access_key          => '${acess_key}',
      prefix              => 'customer',
      application_user    => "wt_appl",
      install_appdynamics => "true"
  }
}
```

Situação 2:
Monitorar a API interna do FE:

``` puppet
class wkl_xpto {

  class { 'wkl_dy9_agent':
      machine_path => 'FE|',
      java_memory  => "-Xms256m -Xmx2048m -XX:PermSize=128M -XX:MaxPermSize=256M",
      service_path => '/opt/FE/api/interna/interna.sh',
      application_name => 'Fe',
      tier_name => 'api_interna',
      access_key => "$access_key",
      prefix => 'api_interna',
      application_user => "fe_appl",
      install_appdynamics => "true"
  }



}
```

## Limitações

Esse modulo não pode ser declarado diretamente na console do puppet.

Esse modulo só aceita aplicações JAVA (por enquanto).

Esse modulo não suporte Windows Server (por enquanto).