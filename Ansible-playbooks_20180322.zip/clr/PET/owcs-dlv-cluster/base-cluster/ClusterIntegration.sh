#!/bin/bash
#Author: Flavio Leandro - DevOps
# Run wlst to create a new Machine and new Managed server on cluster.

ADMIN_HOST=$(cat /app/install/base-cluster/adminHost.txt)
REMOTE_HOST=$(cat /app/install/base-cluster/remoteHost.txt)
NAME_REMOTE_HOST=$(hostname)
USER=${1:-weblogic}
PASS_WLS=$(cat /app/install/base-cluster/password.txt)

/app/oracle/middleware/oracle_common/common/bin/wlst.sh /app/install/cluster.py "$USER" "$PASS_WLS" "$NAME_REMOTE_HOST" "$ADMIN_HOST" "$REMOTE_HOST"
