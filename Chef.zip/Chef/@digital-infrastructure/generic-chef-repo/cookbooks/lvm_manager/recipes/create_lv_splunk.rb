lvm_volume_group 'VG_APP' do
  physical_volumes '/dev/sdb1'

  logical_volume 'lv_splunk' do
    size        '10G'
    filesystem  'xfs'
    mount_point location: '/splunk'
  end
end