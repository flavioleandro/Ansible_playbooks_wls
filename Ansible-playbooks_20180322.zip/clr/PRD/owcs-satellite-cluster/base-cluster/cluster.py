#author: Flavio Leandro -  DevOps
#Create managed Server and set it to cluster

import os
import re
connect(sys.argv[1],sys.argv[2],'t3://'+sys.argv[4]+':7001')
cd('/')

current_server=''
new_server=''

servers = cmo.getServers()
for s in servers:
    name = s.getName()
    port = s.getListenPort();
    if name != 'AdminServer':
        if ref != None:
           current_server = name


nameJvm = " ".join(re.findall("[a-zA-Z_]+", current_server))
jvmId = int(filter(str.isdigit, current_server))
new_server = nameJvm+str((jvmId+1))


#create txt file with name from new webcenter sites node. This file will be used to add another group to start.
f = open('/app/install/base-cluster/hostname.txt','w')
f.write(new_server)
f.close()

edit()
startEdit()
#create machine node on adminserver
#create a unix machine with what ever name suits
##Ler o valor da variável $5 base-cluster/ClusterIntegration.sh
myMachine = cmo.createUnixMachine(sys.argv[3])
#print 'Create machine result: ' + str(myMachine)

#set the nodemanager settings, again that match the settings set up in
#the create domain script
#myMachine.getNodeManager().setNMType('plain')
myMachine.getNodeManager().setListenAddress(sys.argv[5])

#add machine adress to cluster

cd('/')
cd('Clusters/satellite_cluster')
# pega valor atual do cluster e concatena com o novo
cmo.setClusterAddress(cmo.getClusterAddress()+','+sys.argv[5]+':8001' )

#create managed server
cd('/')
cmo.createServer(new_server)
cd('/Servers/' + new_server)
#cmo.setListenAddress(sys.argv[3])
cmo.setMachine(getMBean('/Machines/'+sys.argv[3]))
cmo.setCluster(getMBean('/Clusters/satellite_cluster'))
cmo.setListenPort(port)
cd('/')
cd('/Servers/'+new_server+'/ServerStart/'+new_server)
cmo.setArguments("-server -Xms4G -Xmx16G -Djava.security.egd=file:/dev/./urandom -Dsites.node="+new_server)
#cmo.setClassPath("/u01/shared/config")
activate()

#Enrroling nodemanager to  Adminserver accept new machine.
nmEnroll('/app/oracle/domains/PRD_SAT','/app/oracle/middleware/domains/PRD_SAT/nodemanager/')
exit()
