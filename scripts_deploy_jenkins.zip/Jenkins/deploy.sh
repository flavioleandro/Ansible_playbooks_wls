#!/bin/bash

path_dominio="/u01/oracle/middleware/domains/testeDom";
path_binario="/u01/oracle/middleware/wlserver_10.3";
path_console="t3://10.182.247.100:7001";

echo "Informe o caminho do pacote que será realizado o Deploy.";
read pacote;
if [ ! -f "$pacote" ]; then
	echo "caminho do pacote inválido, favor verifique.";
	exit;
fi

cp -p "$pacote" "$pacote"_BKP
if [ ! -f "$pacote"_BKP  ]; then
	echo "Não foi possível validar o backup do arquivo : "$pacote"_BKP, favor verifique.";
	exit;
fi

echo "Informe o Target (JVM / Cluster) onde será realizado o Deploy.";
read target
if [ -z $target ]; then
	echo "Target não informado, favor verifique.";
	exit;
fi

deploy=$(echo $pacote |awk -F "/" '{ print $NF }' |cut -d"." -f1)

echo "Informe seu usuário da console do Weblogic.";
read usuario;
if [ -z $usuario ]; then
	echo "Usuário não informado, favor verifique.";
	exit;
fi

echo "Informe sua senha da console do Weblogic.";
read -s senha
if [ -z $senha ]; then
	echo "Senha não informada, favor verifique.";
	exit;
fi

cd $path_dominio/bin/
. ./setDomainEnv.sh

java -cp $path_binario/server/lib/weblogic.jar weblogic.WLST /u01/oracle/scripts/deploy.py -u $usuario -p $senha -a $path_console -n $deploy -f "$pacote" -t $target
