hostname = node['hostname'].downcase

execute 'rename_hostname' do
  command "echo #{hostname} > /etc/hostname"
  action :run
end

service 'network' do
  supports status: true, restart: true, reload: true
  action :restart
end
