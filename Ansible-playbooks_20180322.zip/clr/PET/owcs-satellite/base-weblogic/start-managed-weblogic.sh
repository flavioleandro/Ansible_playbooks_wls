#!/bin/bash
#Author: Flavio Leandro -  DevOps
USER=${1:-weblogic}
PASS=$(cat /app/install/base-owcs/password.txt)
HOST=$(cat /app/install/base-owcs/host.txt)

nohup /app/oracle/domains/PET_SAT/bin/startNodeManager.sh &
#star managed server of webcenter sites
echo "****" Starting managed Sites
touch /app/oracle/logs/sites.log
nohup /app/oracle/domains/PET_SAT/bin/startManagedWebLogic.sh satellite_server1 t3://$HOST:7001 >/app/oracle/logs/sites.log &
perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/sites.log
#rm -rf /app/install
