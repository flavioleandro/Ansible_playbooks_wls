require 'spec_helper'
describe 'wkl_ec_rebatedor_transactions' do
  context 'with default values for all parameters' do
    it { should contain_class('wkl_ec_rebatedor_transactions') }
  end
end
