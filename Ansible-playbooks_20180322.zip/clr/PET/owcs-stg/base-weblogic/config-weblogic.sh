#!/bin/bash -x
# Author: Flavio Leandro
DB=$(cat /app/install/base-owcs/dbHost.txt):$(cat /app/install/base-owcs/dbPort.txt)/$(cat /app/install/base-owcs/dbName.txt)
PASS_SCHEMA=$(cat /app/install/base-owcs/schemaPassword.txt)
PASS_WLS=$(cat /app/install/base-owcs/password.txt)
PREFIX=$(cat /app/install/base-owcs/dbPrefix.txt)

/app/oracle/middleware/oracle_common/common/bin/wlst.sh /app/install/config-weblogic.py jdbc:oracle:thin:@$DB "$PASS_WLS" "$PREFIX" "$PASS_SCHEMA"
#sed -i.bak -e 's/WLS_USER=""/WLS_USER="weblogic"/' -e 's/WLS_PW=""/WLS_PW="'$PASS_WLS'"/' -e 's!JAVA_OPTIONS="-Dweblogic!JAVA_OPTIONS="-Djava.security.egd=file:///dev/urandom -Djava.net.preferIPv4Stack=true -Dweblogic!' /u01/oracle/middleware/user_projects/domains/base_domain/bin/startManagedWebLogic.sh
