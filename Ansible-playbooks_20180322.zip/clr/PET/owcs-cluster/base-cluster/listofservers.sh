#!/bin/bash
#Author: Alessandro Souza - DevOps
# Run wlst to create a new Machine and new Managed server on cluster.

REMOTEHOST=$(cat base-cluster/remoteHost.txt)
NODEHOST=$(hostname)
USER=${1:-weblogic}
PASS=$(cat base-cluster/password.txt)

/app/oracle/middleware/oracle_common/common/bin/wlst.sh /home/oracle/owcs-cluster/base-cluster/listofservers.py "$USER" "$PASS" "$REMOTEHOST"
