﻿Import-Module WebAdministration
$iisAppSite = "Default Web Site"
$iisAppPoolName = "Redecard.Ecommerce.Proxy.ME"
$iisAppPoolDotNetVersion = "v4.0"
$iisAppPath = ""
$iisAppName = "Redecard.Ecommerce.Proxy.ME"
$directoryPath = "D:\inetpub\wwwroot\Siglas\EC\adquirencia\Rebatedores\Redecard.Ecommerce.Proxy.ME"

If (!(Test-Path $directoryPath)) {
    mkdir $directoryPath
    }

cd IIS:\AppPools\

if (!(Test-Path $iisAppPoolName -pathType container))
{
    $appPool = New-Item $iisAppPoolName
    $appPool | Set-ItemProperty -Name "managedRuntimeVersion" -Value $iisAppPoolDotNetVersion
}

cd IIS:\Sites\

if (Test-Path $iisAppName -pathType container)
{
    return
}

$iisApp = New-Item IIS:\Sites\$iisAppSite\$iisAppName -physicalPath $directoryPath -type Application
Set-ItemProperty IIS:\Sites\$iisAppSite\$iisAppPath$iisAppName -Name applicationPool -Value $iisAppPoolName