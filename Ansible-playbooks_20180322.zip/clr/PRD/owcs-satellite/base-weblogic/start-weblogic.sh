
#!/bin/bash
#Author: Flavio Leandro -  DevOps
USER=${1:-weblogic}
PASS=$(cat /app/install/base-owcs/password.txt)
HOST=$(cat /app/install/base-owcs/host.txt)

#begin start weblogic
echo "****" Starting weblogic
mkdir -p /app/oracle/logs
touch /app/oracle/logs/admin.log
nohup /app/oracle/domains/PRD_SAT/bin/startWebLogic.sh > /app/oracle/logs/admin.log &
perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/admin.log

add arguments to JVM
/app/oracle/middleware/oracle_common/common/bin/wlst.sh /app/install/arguments.py "$PASS" "$HOST"

