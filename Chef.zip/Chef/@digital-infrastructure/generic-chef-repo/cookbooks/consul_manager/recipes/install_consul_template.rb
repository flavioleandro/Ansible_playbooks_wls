consul_template_zip_file = 'consul-template_0.15.0_linux_amd64.zip'

execute 'unzip_consul_template' do
  command "unzip #{consul_template_zip_file}"
  cwd '/tmp'
  action :nothing
  notifies :run, 'execute[move_consul_template_to_bin]', :delayed
end

execute 'move_consul_template_to_bin' do
  command 'mv /tmp/consul-template /usr/local/bin/consul-template'
  action :nothing
end

remote_file "/tmp/#{consul_template_zip_file}" do
  source "https://releases.hashicorp.com/consul-template/0.15.0/#{consul_template_zip_file}"
  owner 'root'
  group 'root'
  mode '0755'
  action :create
  notifies :run, 'execute[unzip_consul_template]', :immediately
end


