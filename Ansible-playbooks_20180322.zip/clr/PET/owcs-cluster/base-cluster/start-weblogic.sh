#!/bin/bash
#Author: Alessandro Souza- DevOps
#Start Weblogic in the new machine

SERVER=$(cat base-cluster/webcenter_node.txt)
REMOTEHOST=$(cat base-cluster/remoteHost.txt)
USER=${1:-weblogic}
PASS=$(cat base-cluster/password.txt)

. ./base-cluster/exportOptions.sh

/app/oracle/middleware/oracle_common/common/bin/wlst.sh /home/oracle/owcs-cluster/base-cluster/start.py "$REMOTEHOST" "$SERVER" "$USER" "$PASS"
