yum_package 'wget' do
  action :install
end

cookbook_file '/etc/wgetrc' do
  source 'etc/wgetrc'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

hostname = node['hostname']

template '/etc/chef/client.rb' do
  source 'client.rb.erb'
  owner 'root'
  group 'root'
  mode '0644'
  variables(
    hostname: hostname.downcase
  )
  action :create
end
