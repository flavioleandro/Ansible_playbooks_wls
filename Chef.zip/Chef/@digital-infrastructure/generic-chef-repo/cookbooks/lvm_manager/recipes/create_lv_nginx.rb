lvm_volume_group 'VG_APP' do
  physical_volumes '/dev/sdb1'

  logical_volume 'lv_nginx' do
    size        '49G'
    filesystem  'xfs'
    mount_point location: '/var/lib/docker'
  end
end