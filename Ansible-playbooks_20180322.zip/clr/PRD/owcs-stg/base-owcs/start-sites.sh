#!/bin/bash
nohup /app/oracle/domains/PRD_STG/bin/startNodeManager.sh &
nohup /app/oracle/domains/PRD_STG/bin/startManagedWebLogic.sh wcsites_server1 t3://"$(cat /app/install/base-owcs/host.txt)":7001 >/app/oracle/logs/sites.log &
