microservice = node['microservice']
Chef::Log.warn("Executing deploy of microservice: #{microservice}")

cookbook_file '/home/microservice/.docker/config.json' do
  source 'config.json'
  owner 'microservice'
  group 'microservice'
  mode '0600'
  action :create
end

directory '/home/microservice/log4j' do
  owner 'microservice'
  group 'microservice'
  mode '0755'
  action :create
end

docker_image_cmd = Mixlib::ShellOut.new("docker images -q -f 'label=SERVICE_NAME=#{microservice}'")
docker_image_cmd.run_command
docker_image = docker_image_cmd.stdout

execute 'stop_container' do
  cwd '/home/microservice/docker/compose/'
  command "sudo -H -u microservice bash -c '/usr/local/bin/docker-compose -f digital.yml stop #{microservice} && /usr/local/bin/docker-compose -f digital.yml rm --force #{microservice}'"
  action :run
  only_if { docker_image != '' }
end

execute 'delete_image' do
  cwd '/home/microservice/docker/compose/'
  ignore_failure true
  command "sudo -H -u microservice bash -c 'docker rmi -f $(docker images -q -f 'label=SERVICE_NAME=#{microservice}')'"
  action :run
  only_if { docker_image != '' }
end

execute 'deploy_new_image' do
  cwd '/home/microservice/docker/compose/'
  command "sudo -H -u microservice bash -c '/usr/local/bin/docker-compose -f digital.yml up -d --force-recreate #{microservice}'"
  action :run
end

dangling_images_cmd = Mixlib::ShellOut.new("docker images -q -f 'dangling=true'")
dangling_images_cmd.run_command
dangling_images = dangling_images_cmd.stdout

execute 'clean_trash_images' do
  cwd '/home/microservice/docker/compose/'
  command "sudo -H -u microservice bash -c 'docker rmi -f $(docker images -q -f 'dangling=true')'"
  action :run
  only_if { dangling_images != '' }
end
