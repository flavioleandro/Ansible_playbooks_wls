#!/bin/bash
#Author: Flavio Leandro -  DevOps
USER=${1:-weblogic}
PASS=$(cat /app/install/base-owls/password.txt)
HOST=$(cat /app/install/base-owls/host.txt)

#begin start NodeManager
nohup /app/oracle/domains/PET_CAD/bin/startNodeManager.sh &

#begin start WebLogic
echo "****" Starting weblogic
mkdir -p /app/oracle/logs
touch /app/oracle/logs/admin.log
nohup /app/oracle/domains/PET_CAD/bin/startWebLogic.sh > /app/oracle/logs/admin.log &
perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/admin.log

#begin start Managed Server
echo "****" Starting Managed Server
mkdir -p /app/oracle/logs
touch /app/oracle/logs/server_01.log
nohup /app/oracle/domains/PET_CAD/bin/startManagedWebLogic.sh server_01 t3://"$(cat /app/install/base-owls/host.txt)":7001 >/app/oracle/logs/server_01.log &
#nohup /app/oracle/domains/PET_CAD/bin/startManagedWebLogic.sh server_01 t3://$HOST:7001 >/app/oracle/logs/server_01.log &
perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/server_01.log


#add arguments to JVM
#/app/oracle/middleware/oracle_common/common/bin/wlst.sh /app/install/arguments.py "$PASS"
#echo "****" Granting Permissions
#cp /app/oracle/domains/WCP_Domain/wcportal/bin/grant-opss-permission.py /app/oracle/domains/WCP_Domain/wcportal/bin/grant-opss-permission.py.bkp
#sed -i 's|'grant-opss-permission.py'|/app/oracle/middleware/domains/WCP_Domain/wcportal/bin/grant-opss-permission.py|g' /app/oracle/domains/WCP_Domain/wcportal/bin/grant-opss-permission.sh
#/app/oracle/domains/WCP_Domain/wcportal/bin/grant-opss-permission.sh "$USER" "$PASS"

#start managed server of Webcenter Portal
#echo "****" Starting managed server-01
#touch /app/oracle/logs/api.log
#nohup /app/oracle/domains/WCP_Domain/bin/startManagedWebLogic.sh WC_Portal t3://$HOST:7001 >/app/oracle/logs/WC_Portal.log &
#perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/WC_Portal.log
#rm -rf /app/install
