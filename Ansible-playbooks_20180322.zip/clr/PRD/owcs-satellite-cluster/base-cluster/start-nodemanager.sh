#!/bin/bash
#Author: Flavio Leandro- DevOps
#Start NodeManager in the new machine

/app/oracle/domains/PRD_SAT/bin/startNodeManager.sh &
