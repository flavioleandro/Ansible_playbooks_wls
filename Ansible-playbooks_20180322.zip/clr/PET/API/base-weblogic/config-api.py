#!author : Tim Hall
# Save Script as : create_domain.py

import time
import getopt
import sys
import re

# Get location of the properties file.
properties = ''
try:
   opts, args = getopt.getopt(sys.argv[1:],"p:h::",["properies="])
except getopt.GetoptError:
   print 'config-weblogic.py -p <path-to-properties-file>'
   sys.exit(2)
for opt, arg in opts:
   if opt == '-h':
      print 'config-weblogic.py -p <path-to-properties-file>'
      sys.exit()
   elif opt in ("-p", "--properties"):
      properties = arg
print 'properties=', properties

# Load the properties from the properties file.
from java.io import FileInputStream

propInputStream = FileInputStream(properties)
configProps = Properties()
configProps.load(propInputStream)

# Set all variables from values in properties file.

adminusername=configProps.get("adminusername")
adminpassword=configProps.get("adminpassword")
adminurl=configProps.get("adminurl")
clusterName=configProps.get("cluster.name")
clusterAddress=configProps.get("cluster.address")
msMachine=configProps.get("ms.machine")

# Display the variable values.
print 'adminUsername=', adminusername
print 'adminPassword=', adminpassword
print 'adminURL=', adminurl
print 'clusterName=', clusterName
print 'clusterAddress=', clusterAddress

# Connect to the AdminServer.
connect(adminusername, adminpassword, adminurl)

edit()

startEdit()

cd('/')

# create a server with the provided name

cmo.createServer('server_01')
# change to the new server mbean

cd('/Servers/server_01')
# set server details like host, port, ?

cmo.setListenAddress(None)
cmo.setListenPort(9001)

# configure basic server settings
cmo.setListenPortEnabled(true)
cmo.setJavaCompiler('javac')
cmo.setClientCertProxyEnabled(false)
cmo.setCluster(None)
cd('/Servers/server_01/ServerDiagnosticConfig/server_01')
cmo.setWLDFDiagnosticVolume('Low')
cd('/Servers/server_01')
cmo.setMachine(getMBean('/Machines/' + msMachine))

# Create cluster Api.
cd('/')
cmo.createCluster(clusterName)

cd('/Clusters/' + clusterName)
cmo.setClusterMessagingMode('unicast')
cmo.setClusterBroadcastChannel('')
cmo.setClusterAddress(clusterAddress)
cmo.setReplicationChannel('ReplicationChannel')
cmo.setClusterType('man')

def createUnixMachine(serverMachine,serverAddress):
  print('\nCreate machine '+serverMachine+' with type UnixMachine')
  cd('/')
  create(serverMachine,'UnixMachine')
  cd('UnixMachine/'+serverMachine)
  create(serverMachine,'NodeManager')
  cd('NodeManager/'+serverMachine)
  set('ListenAddress',serverAddress)

def addServerToMachine(serverName, serverMachine):
  print('\nAdd server '+serverName+' to '+serverMachine)
  cd('/Servers/'+serverName)
  set('Machine',serverMachine)
  set('ListenPort', int('9001'))

cd('/Servers/server_01')
cmo.setCluster(getMBean('/Clusters/wls_cluster'))

save()
activate(block="true")
disconnect()
exit()
