execute 'remove_redislabs' do
  command 'yum remove redislabs-4.3.0-230.rhel7.x86_64 -y'
  cwd '/opt'
  action :run
end

directory '/tmp/redislabs' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/tmp/redislabs/redislabs-4.3.0-230-rhel7-x86_64.tar' do
  source 'https://s3.amazonaws.com/rlec-downloads/4.3.0/redislabs-4.3.0-230-rhel7-x86_64.tar'
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

execute 'untar_redis' do
  command '/usr/bin/tar -xvf /tmp/redislabs/redislabs-4.3.0-230-rhel7-x86_64.tar'
  cwd '/tmp/redislabs'
  action :run
end

execute 'install_redislabs' do
  command '/tmp/redislabs/install.sh -y'
  cwd '/tmp/redislabs'
  action :run
end

#directory '/tmp/redislabs' do
#   recursive true
#   action :delete
#end