
#!/bin/bash
#Author: Flavio Leandro -  DevOps
USER=${1:-weblogic}
PASS=$(cat /app/install/base-owcs/password.txt)
HOST=$(cat /app/install/base-owcs/host.txt)

#begin start weblogic
echo "****" Starting weblogic
mkdir -p /app/oracle/logs
touch /app/oracle/logs/admin.log
nohup /app/oracle/domains/PRD_DLV/bin/startWebLogic.sh > /app/oracle/logs/admin.log &
perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/admin.log

add arguments to JVM
/app/oracle/middleware/oracle_common/common/bin/wlst.sh /app/install/arguments.py "$PASS"
echo "****" Granting Permissions
cp /app/oracle/domains/PRD_DLV/wcsites/bin/grant-opss-permission.py /app/oracle/domains/PRD_DLV/wcsites/bin/grant-opss-permission.py.bkp
sed -i 's|'grant-opss-permission.py'|/app/oracle/middleware/domains/PRD_DLV/wcsites/bin/grant-opss-permission.py|g' /app/oracle/domains/PRD_DLV/wcsites/bin/grant-opss-permission.sh
/app/oracle/domains/PRD_DLV/wcsites/bin/grant-opss-permission.sh "$USER" "$PASS"

#star managed server of webcenter sites
echo "****" Starting managed Sites
touch /app/oracle/logs/sites.log
nohup /app/oracle/domains/PRD_DLV/bin/startManagedWebLogic.sh wcsites_server1 t3://$HOST:7001 >/app/oracle/logs/sites.log &
perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/sites.log
#rm -rf /app/install
