import getopt
# Load the properties file with all necessary values
loadProperties('/app/install/myDomain-cluster.properties')
# Split the provided Server List String for the FOR LOOP in start and stop command
serverlistSplit=String(serverlist).split(",")

# Get the command, must be 'start' or 'stop'
getcommand=sys.argv[1]

# Check the provided command
if getcommand != 'start' and getcommand != 'stop':
  print 'usage: <start stop="stop">'
  exit()

# Connect to the Weblogic Admin Server
# Connection Details are retrieved from properties file
connect(adminusername, adminpassword, adminurl)

# Change to the root of the MBean hierarchy
domainRuntime()

# Start Block
if getcommand == 'start':
   # Loop over the splitted Server List string
   for s in serverlistSplit:
     # Is a ServerRuntime MBean existing for current Managed Server?
     # If yes, the current Managed Server is already running and we dont need to do anything
     bean = getMBean('ServerRuntimes/' + s)
     if bean:
       print 'Server ' + s + ' is ' + bean.getState()
     else:
       start(s, 'Server', block='false')
       print 'Started Server ' + s

# Stop Block
if getcommand == 'stop':
   # Loop over the splitted Server List string
for s in serverlistSplit:
     # Is a ServerRuntime MBean existing for current Managed Server?
     # If no, the current Managed Server is already down and we dont need to do anything
     bean = getMBean('ServerRuntimes/' + s)
     if bean:
       shutdown(s, 'Server')
       print 'Stopped Server ' + s
     else:
       print 'Server ' + s + ' is not running'

disconnect()
exit()
