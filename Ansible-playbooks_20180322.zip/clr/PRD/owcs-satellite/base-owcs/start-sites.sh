#!/bin/bash
nohup /app/oracle/domains/PRD_SAT/bin/startNodeManager.sh &
nohup /app/oracle/domains/PRD_SAT/bin/startManagedWebLogic.sh satellite_server1 t3://"$(cat /app/install/base-owcs/host.txt)":7001 >/app/oracle/logs/sites.log &
