require 'spec_helper'

describe 'infra_ldap::config' do
  on_supported_os.each do |os, os_facts|
    context "on #{os}" do
      let(:facts) { os_facts }

      it { is_expected.to contain_file('nslcd.conf').with_path('/etc/nslcd.conf') }
      it { is_expected.to contain_file('krb5.conf').with_path('/etc/krb5.conf') }
      it { is_expected.to contain_file('nscd.conf').with_path('/etc/nscd.conf') }
      it { is_expected.to contain_file('nsswitch.conf').with_path('/etc/nsswitch.conf') }
      it { is_expected.to contain_file('system-auth-ac').with_path('/etc/pam.d/system-auth-ac') }
      it { is_expected.to contain_file('password-auth-ac').with_path('/etc/pam.d/password-auth-ac') }
      it { is_expected.to contain_file('sshd').with_path('/etc/pam.d/sshd') }
    end
  end
end
