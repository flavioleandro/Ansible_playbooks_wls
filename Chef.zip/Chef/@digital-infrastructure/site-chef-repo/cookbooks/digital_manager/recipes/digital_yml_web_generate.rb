service_name = ENV['SERVICE_NAME']

Chef::Log.warn("Service Name: #{service_name}")

microservice_data = data_bag_item('microservices', service_name)
microservice_name = microservice_data['id']
location = microservice_data['location']

# Gerando diretório para armazenar os arquivos de configuração de cada microservice
# que será gerenciado pelo NGINX
directory '/home/microservice/docker/compose/nginx/includes' do
  owner 'microservice'
  group 'microservice'
  mode '0755'
  action :create
  recursive true
end

environment_tag = if tagged?('blue')
                    'blue'
                  elsif tagged?('green')
                    'green'
                  elsif tagged?('non-prd')
                    'non-prd'
                  end

# Gerando arquivos .conf de upstream para alimentar o nginx.conf
template "/home/microservice/docker/compose/nginx/includes/#{microservice_name}_upstream.conf" do
  source 'upstream.conf.erb'
  owner 'microservice'
  group 'microservice'
  mode '0644'
  variables(
    microservice: microservice_name,
    environment: node.chef_environment,
    environment_tag: environment_tag
  )
  action :create
end

# Gerando arquivos .conf de location para alimentar o nginx.conf
template "/home/microservice/docker/compose/nginx/includes/#{microservice_name}_location.conf" do
  source 'location.conf.erb'
  owner 'microservice'
  group 'microservice'
  mode '0644'
  variables(
    microservice: microservice_name,
    location: location
  )
  action :create
end

# Gerando arquivo upstream.conf
execute 'generate_nginx_upstream' do
  user 'microservice'
  group 'microservice'
  cwd '/home/microservice/docker/compose/nginx/includes/'
  command 'cat *_upstream.conf > upstream.template'
  action :run
end

# Gerando arquivo location.conf
execute 'generate_nginx_location' do
  user 'microservice'
  group 'microservice'
  cwd '/home/microservice/docker/compose/nginx/includes/'
  command 'cat *_location.conf > location.conf'
  action :run
end

cookbook_file '/home/microservice/docker/compose/nginx/nginx.conf' do
  source 'nginx.conf'
  user 'microservice'
  group 'microservice'
  mode '0644'
  action :create
end

service 'consul-template' do
  supports status: true, restart: true, reload: true
  action [:restart]
end
