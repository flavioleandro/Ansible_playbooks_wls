import os
import re
connect('weblogic',sys.argv[1],'t3://localhost:7001')

edit()
startEdit()

cd('/')
cd('/Servers/satellite_server1/ServerStart/satellite_server1')
cmo.setArguments('-server -Xms4G -Xmx8G -Djava.security.egd=file:/dev/./urandom -Dsites.node=satellite_server1')
activate()
exit()
