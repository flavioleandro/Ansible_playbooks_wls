require 'spec_helper'
describe 'infra_wf' do
  context 'with default values for all parameters' do
    it { should contain_class('infra_wf') }
  end
end
