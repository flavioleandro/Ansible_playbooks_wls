cookbook_file '/etc/hosts' do
  source 'etc/hosts'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end
