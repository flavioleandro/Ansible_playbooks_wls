lvm_volume_group 'VG_APP' do
  physical_volumes '/dev/sdb1'

  logical_volume 'lv_consul' do
    size        '49999M'
    filesystem  'xfs'
    mount_point location: '/var/lib/consul'
  end
end