## API host configurado no 'Default Attributes' de cada 'Environment'
api_Host = node['apiHost']

data_bag('microservices').each do |microservice|
  microservice_data = data_bag_item('microservices', microservice)
  microservice_name = microservice_data['id']
  image = microservice_data['image']
  version = microservice_data['version']
  port = microservice_data['port']
  location = microservice_data['location']
  log_level = if microservice_data['log_level'].nil? || microservice_data['log_level'].empty?
                'INFO'
              else
                microservice_data['log_level']
              end

  # Gerando diretório para armazenar os arquivos de configuração de cada microservice
  directory '/home/microservice/docker/compose/microservices' do
    owner 'microservice'
    group 'microservice'
    mode '0755'
    action :create
  end

  # Gerando diretório para armazenar os arquivos de configuração de cada microservice
  # que será gerenciado pelo NGINX
  directory '/home/microservice/docker/compose/nginx/includes' do
    owner 'microservice'
    group 'microservice'
    mode '0755'
    action :create
  end

  # Gerando arquivo de log
  cookbook_file "/home/microservice/log4j/#{microservice_name}-log4j2.xml" do
    source 'log4j2.xml'
    owner 'microservice'
    group 'microservice'
    mode '0644'
    action :create
  end

  # Gerando arquivos .yml que serão utilizados para gerar o arquivo digital.yml
  template "/home/microservice/docker/compose/microservices/#{microservice_name}.yml" do
    source 'microservice.yml.erb'
    owner 'microservice'
    group 'microservice'
    mode '0644'
    variables(
      microservice: microservice_name,
      image: image,
      version: version,
      api_host: api_Host,
      port: port,
      splunk_host: node['ipaddress'],
      splunk_port: '8514',
      host_ip: node['ipaddress'],
      log_level: log_level
    )
    action :create
  end

  # Gerando arquivos .json que serão utilizados pelo Chef como 
  # variáveis de ambiente durante o deploy
  template "/home/microservice/docker/compose/microservices/#{microservice_name}.json" do
    source 'microservice.json.erb'
    owner 'microservice'
    group 'microservice'
    mode '0644'
    variables(
      microservice: microservice_name,
      image: image,
      version: version,
      api_host: api_Host,
      port: port
    )
    action :create
  end

  # Gerando arquivos .conf de upstream para alimentar o nginx.conf
  template "/home/microservice/docker/compose/nginx/includes/#{microservice_name}_upstream.conf" do
    source 'upstream.conf.erb'
    owner 'microservice'
    group 'microservice'
    mode '0644'
    variables(
      microservice: microservice_name,
      environment: node.chef_environment
    )
    action :create
  end

  # Gerando arquivos .conf de location para alimentar o nginx.conf
  template "/home/microservice/docker/compose/nginx/includes/#{microservice_name}_location.conf" do
    source 'location.conf.erb'
    owner 'microservice'
    group 'microservice'
    mode '0644'
    variables(
      microservice: microservice_name,
      location: location
    )
    action :create
  end
  
end

# Gerando arquivo digital.yml
execute 'generate_digital_yml' do
  user 'microservice'
  group 'microservice'
  cwd '/home/microservice/docker/compose/'
  command 'cat microservices/*.yml > digital.yml'
  action :run
end

# Gerando arquivo upstream.conf
execute 'generate_nginx_upstream' do
  user 'microservice'
  group 'microservice'
  cwd '/home/microservice/docker/compose/nginx/includes/'
  command 'cat *_upstream.conf > upstream.template'
  action :run
end

# Gerando arquivo location.conf
execute 'generate_nginx_location' do
  user 'microservice'
  group 'microservice'
  cwd '/home/microservice/docker/compose/nginx/includes/'
  command 'cat *_location.conf > location.conf'
  action :run
end

cookbook_file '/home/microservice/docker/compose/nginx/nginx.conf' do
  source 'nginx.conf'
  user 'microservice'
  group 'microservice'
  mode '0644'
  action :create
end

template "/home/microservice/docker/compose/nginx.yml" do
  source 'nginx.yml.erb'
  owner 'microservice'
  group 'microservice'
  mode '0644'
  variables(
    api_host: api_Host
  )
  action :create
end

service 'consul-template' do
  supports status: true, restart: true, reload: true
  action [:restart]
end
