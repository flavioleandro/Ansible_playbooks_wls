#!/bin/bash
#Author: Flavio Leandro - DevOps
OP=${1:-create}
#OP=${1:-delete}
DB=$(cat /app/install/base-owcs/dbHost.txt):$(cat /app/install/base-owcs/dbPort.txt)/$(cat /app/install/base-owcs/dbName.txt)
PASS=$(cat /app/install/base-owcs/dbPassword.txt)
SCHEMA_PASS=$(cat /app/install/base-owcs/schemaPassword.txt)
PREFIX=$(cat /app/install/base-owcs/dbPrefix.txt)
HOST=$(echo $DB | sed -e 's/:.*//')

case $OP in
create)
   # fix for oraclexe
    printf "%s\\n%s\\n" "$PASS" "$SCHEMA_PASS" | /app/oracle/middleware/oracle_common/bin/rcu -silent \
    -createRepository -connectString "$DB" -dbUser SYS -dbRole SYSDBA \
    -useSamePasswordForAllSchemaUsers true -schemaPrefix "$PREFIX" \
    -component STB -component OPSS \
    -component IAU -component IAU_APPEND -component IAU_VIEWER -honorOMF true
;;
delete)
   echo $PASS | /app/oracle/middleware/oracle_common/bin/rcu -silent -dropRepository -connectString $DB -dbUser SYS -dbRole SYSDBA -schemaPrefix $PREFIX -component STB -component OPSS -component IAU -component IAU_APPEND -component IAU_VIEWER
;;
*) echo "usage: create|delete" ;;
esac


