#!/bin/bash
#Author: Flavio Leandro- DevOps
#Start Weblogic in the new machine
nohup /app/oracle/domains/PET_SAT/bin/startNodeManager.sh &
#start managed server of Satellite
echo "****" Starting managed Sites
mkdir -p /app/oracle/logs/
touch /app/oracle/logs/sites.log
mkdir -p /cms/satellite/config
cp /app/oracle/domains/PET_SAT/wcsites/wcsites/config/wcs_properties.json /cms/satellite/config
mkdir -p /app/oracle/domains/PET_SAT/servers/$(cat /app/install/base-cluster/webcenter_node.txt)/security
cp /app/oracle/domains/PET_SAT/servers/satellite_server1/security/boot.properties /app/oracle/domains/PET_SAT/servers/$(cat /app/install/base-cluster/webcenter_node.txt)/security
nohup /app/oracle/domains/PET_SAT/bin/startManagedWebLogic.sh $(cat /app/install/base-cluster/webcenter_node.txt) t3://$(cat /app/install/base-cluster/adminHost.txt):7001 >/app/oracle/logs/sites.log &
perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/sites.log

