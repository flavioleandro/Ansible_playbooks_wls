# Load the properties file with all necessary values
loadProperties('/app/install/base-cluster/domain.properties')

# Get the command, must be 'start' or 'stop'
getcommand=sys.argv[1]

s=sys.argv[2]

# Check the provided command
if getcommand != 'start' and getcommand != 'stop':
  print 'usage: <start stop="stop">'
  exit()

# Connect to the Weblogic Admin Server
# Connection Details are retrieved from properties file
connect(adminusername, adminpassword, adminurl)

#edit()
#startEdit()

# Start Block
if getcommand == 'start':
   # Loop over the splitted Server List string
   #for s in serverlistSplit:
     # Is a ServerRuntime MBean existing for current Managed Server?
     # If yes, the current Managed Server is already running and we dont need to do anything
     status = state(s)


     if status != "Current state of \""+s+"\" : RUNNING" :
     #if status.find("RUNNING") != -1 :
       start(s)


# Stop Block
if getcommand == 'stop':
     status = state(s)
     #if status != "Current state of \""+s+"\" : SHUTDOWN" :
     #if "SHUTDOWN" not in status :
     if status != "Current state of \""+s+"\" : SHUTDOWN" :
       shutdown(s,'Server','true',1000,'true')

disconnect('true')
exit()
