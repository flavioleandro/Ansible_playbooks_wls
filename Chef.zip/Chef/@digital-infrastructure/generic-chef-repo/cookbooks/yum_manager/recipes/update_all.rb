execute 'yum-update' do
  command 'yum update -y'
  action :run
end

