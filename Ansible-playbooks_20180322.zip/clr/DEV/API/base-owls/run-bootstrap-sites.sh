#!/bin/bash
#Author: Flavio Leandro
/app/install/bootstrap-sites.sh "$(cat /app/install/base-owcs/apache.txt)" "$(cat /app/install/base-owcs/apachePort.txt)" "$(cat /app/install/base-owcs/db.txt)" "$(cat /app/install/base-owcs/password.txt)"
