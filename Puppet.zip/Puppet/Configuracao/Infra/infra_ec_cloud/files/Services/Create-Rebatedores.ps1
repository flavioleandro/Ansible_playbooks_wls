﻿$drive = "D:"

$rebatedorintegration = "$drive\Inetpub\wwwroot\Siglas\EC\adquirencia\Rebatedores\RebatedorIntegration"
$rebatedorkc = "$drive\Inetpub\wwwroot\Siglas\EC\adquirencia\Rebatedores\RebatedorKC"
$rebatedorme = "$drive\Inetpub\wwwroot\Siglas\EC\adquirencia\Rebatedores\RebatedorME"
$rebatedormx5 = "$drive\Inetpub\wwwroot\Siglas\EC\adquirencia\Rebatedores\RebatedorMX5"
$rebatedorsw = "$drive\Inetpub\wwwroot\Siglas\EC\adquirencia\Rebatedores\RebatedorSW"
$rebatedorfe = "$drive\Inetpub\wwwroot\Siglas\EC\adquirencia\Rebatedores\RebatedorFE"
$rebatedorsync = "$drive\Inetpub\wwwroot\Siglas\EC\adquirencia\Rebatedores\RebatedorSync"
$rebatedorlogintegration = "$drive\Inetpub\wwwroot\Siglas\EC\logs\adquirencia\Rebatedores\RebatedorIntegration"
$rebatedorlogkc = "$drive\Inetpub\wwwroot\Siglas\EC\logs\adquirencia\Rebatedores\RebatedorKC"
$rebatedorlogme = "$drive\Inetpub\wwwroot\Siglas\EC\logs\adquirencia\Rebatedores\RebatedorME"
$rebatedorlogmx5 = "$drive\Inetpub\wwwroot\Siglas\EC\logs\adquirencia\Rebatedores\RebatedorMX5"
$rebatedorlogsw = "$drive\Inetpub\wwwroot\Siglas\EC\logs\adquirencia\Rebatedores\RebatedorSW"
$rebatedorlogfe = "$drive\Inetpub\wwwroot\Siglas\EC\logs\adquirencia\Rebatedores\RebatedorFE"
$rebatedorlogsync = "$drive\Inetpub\wwwroot\Siglas\EC\logs\adquirencia\Rebatedores\RebatedorSync"

If (!(Test-Path $rebatedorintegration)) {
    mkdir $rebatedorintegration
    }
If (!(Test-Path $rebatedorkc)) {
	mkdir $rebatedorkc
	}
If (!(Test-Path $rebatedorme)) {
	mkdir $rebatedorme
	}
If (!(Test-Path $rebatedormx5)) {
	mkdir $rebatedormx5
	}
If (!(Test-Path $rebatedorsw)) {
	mkdir $rebatedorsw
	}
If (!(Test-Path $rebatedorfe)) {
	mkdir $rebatedorfe
	}
If (!(Test-Path $rebatedorsync)) {
	mkdir $rebatedorsync
	}
If (!(Test-Path $rebatedorlogintegration)) {
	mkdir $rebatedorlogintegration
	}
If (!(Test-Path $rebatedorlogkc)) {
	mkdir $rebatedorlogkc
	}
If (!(Test-Path $rebatedorlogme)) {
	mkdir $rebatedorlogme
	}
If (!(Test-Path $rebatedorlogmx5)) {
	mkdir $rebatedorlogmx5
	}
If (!(Test-Path $rebatedorlogsw)) {
	mkdir $rebatedorlogsw
	}
If (!(Test-Path $rebatedorlogfe)) {
	mkdir $rebatedorlogfe
	}
If (!(Test-Path $rebatedorlogsync)) {
	mkdir $rebatedorlogsync
	}