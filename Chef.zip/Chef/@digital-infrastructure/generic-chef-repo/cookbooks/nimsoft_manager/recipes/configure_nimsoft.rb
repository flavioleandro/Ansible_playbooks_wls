cookbook_file '/opt/nms-robot-vars.cfg' do
  source 'nms-robot-vars.cfg'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

execute 'run_RobotConfigurer' do
  command "/opt/nimsoft/install/RobotConfigurer.sh"
  cwd '/opt/nimsoft/install'
  action :run
end

service 'nimbus' do
  supports status: true, restart: true, reload: true
  action [:enable, :restart]
end