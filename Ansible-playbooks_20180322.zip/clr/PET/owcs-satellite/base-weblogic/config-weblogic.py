#Author: Flavio Leandro -  DevOps
#Project: Presenca Digital
import socket

readTemplate("/app/oracle/middleware/wlserver/common/templates/wls/wls.jar")
addTemplate("/app/oracle/middleware/wlserver/common/templates/wls/wls_coherence_template.jar")
addTemplate("/app/oracle/middleware/oracle_common/common/templates/wls/oracle.jrf_template.jar")
addTemplate("/app/oracle/middleware/em/common/templates/wls/oracle.em_wls_template.jar")
addTemplate("/app/oracle/middleware/wcsites/common/templates/wls/oracle.wcsites.satelliteserver.template.jar")

# set pw
cd('Servers/AdminServer')
set('ListenPort', 7001)
cd('/')
cd('Security/base_domain/User/weblogic')
cmo.setPassword(sys.argv[2])

cd('/')

setOption('ServerStartMode','prod')

cd('/')
#====================================================================

print 'Change datasource LocalScvTblDataSource'
cd('/JDBCSystemResource/LocalSvcTblDataSource/JdbcResource/LocalSvcTblDataSource/JDBCDriverParams/NO_NAME_0')
set('URL',sys.argv[1])
set('PasswordEncrypted',sys.argv[4])
cd('Properties/NO_NAME_0/Property/user')
set('Value',sys.argv[3]+'_STB')

print 'Change datasource opss-audit-DBDS'
cd('/JDBCSystemResource/opss-audit-DBDS/JdbcResource/opss-audit-DBDS/JDBCDriverParams/NO_NAME_0')
set('URL',sys.argv[1])
set('PasswordEncrypted',sys.argv[4])
cd('Properties/NO_NAME_0/Property/user')
set('Value',sys.argv[3]+'_IAU_APPEND')

print 'Change datasource opss-audit-viewDS'
cd('/JDBCSystemResource/opss-audit-viewDS/JdbcResource/opss-audit-viewDS/JDBCDriverParams/NO_NAME_0')
set('URL',sys.argv[1])
set('PasswordEncrypted',sys.argv[4])
cd('Properties/NO_NAME_0/Property/user')
set('Value',sys.argv[3]+'_IAU_VIEWER')

print 'Change datasource opss-data-source'
cd('/JDBCSystemResource/opss-data-source/JdbcResource/opss-data-source/JDBCDriverParams/NO_NAME_0')
set('URL',sys.argv[1])
set('PasswordEncrypted',sys.argv[4])
cd('Properties/NO_NAME_0/Property/user')
set('Value',sys.argv[3]+'_OPSS')

# Create a Unix Machine
def createUnixMachine(serverMachine,serverAddress):
  print('\nCreate machine '+serverMachine+' with type UnixMachine')
  cd('/')
  create(serverMachine,'UnixMachine')
  cd('UnixMachine/'+serverMachine)
  create(serverMachine,'NodeManager')
  cd('NodeManager/'+serverMachine)
  set('ListenAddress',serverAddress)

def createBootPropertiesFile(directoryPath,fileName, username, password):
  print ('Create Boot Properties File for folder: '+directoryPath)
  serverDir = File(directoryPath)
  bool = serverDir.mkdirs()
  fileNew=open(directoryPath + '/'+fileName, 'w')
  fileNew.write('username=%s\n' % username)
  fileNew.write('password=%s\n' % password)
  fileNew.flush()
  fileNew.close()

# Add server to  Unix Machine
def addServerToMachine(serverName, serverMachine):
  print('\nAdd server '+serverName+' to '+serverMachine)
  cd('/Servers/'+serverName)
  set('Machine',serverMachine)
  set('ListenPort', int('9001'))


# create clcuster
def createCluster(jvm,clusterName):
  cd('/')
  create(clusterName,'Cluster')
  assign('Server',jvm,'Cluster',clusterName)
  cd('Clusters/'+clusterName)
  set("ClusterMessagingMode", "unicast")
  set('ClusterAddress',socket.gethostname()+':8001')
  set("PersistSessionsOnShutdown", "false")
  set("ReplicationChannel", "ReplicationChannel")
  set("SecureReplicationEnabled", "false")
  set("ClusterType", "man")
  set("PersistSessionsOnShutdown", "false")
  set("ReplicationChannel", "ReplicationChannel")

#create cluster
createCluster('satellite_server1','satellite_cluster')
#create machine
createUnixMachine(socket.gethostname(),socket.gethostname())
#add server to machine
addServerToMachine('satellite_server1',socket.gethostname())

# setOption('NoDependencyCheck', 'true')
writeDomain('/app/oracle/domains/PET_SAT')
closeTemplate()
createBootPropertiesFile('/app/oracle/domains/PET_SAT/servers/AdminServer/security','boot.properties','weblogic',sys.argv[2])
createBootPropertiesFile('/app/oracle/domains/PET_SAT/servers/satellite_server1/security','boot.properties','weblogic',sys.argv[2])
exit()
