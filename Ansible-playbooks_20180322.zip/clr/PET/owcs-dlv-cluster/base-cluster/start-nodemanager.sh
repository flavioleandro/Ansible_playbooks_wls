#!/bin/bash
#Author: Flavio Leandro- DevOps
#Start NodeManager in the new machine

/app/oracle/domains/PET_DLV/bin/startNodeManager.sh &
