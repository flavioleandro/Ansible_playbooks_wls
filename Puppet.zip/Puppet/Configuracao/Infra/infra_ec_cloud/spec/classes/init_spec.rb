require 'spec_helper'
describe 'infra_ec_cloud' do
  context 'with default values for all parameters' do
    it { should contain_class('infra_ec_cloud') }
  end
end
