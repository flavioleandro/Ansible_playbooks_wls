Import-Module WebAdministration
$iisAppSite = "erede.api"
$iisAppPoolName = "erede.api.v1"
$iisAppPoolDotNetVersion = "v4.0"
$iisAppPath = ""
$iisAppName = "v1"
$directoryPath = "D:\inetpub\WWWRoot\Siglas\EC\erede.api\v1\"

If (!(Test-Path $directoryPath)) {
    mkdir $directoryPath
    }

cd IIS:\AppPools\

if (!(Test-Path $iisAppPoolName -pathType container))
{
    $appPool = New-Item $iisAppPoolName
    $appPool | Set-ItemProperty -Name "managedRuntimeVersion" -Value $iisAppPoolDotNetVersion
}

cd IIS:\Sites\

if (Test-Path $iisAppName -pathType container)
{
    return
}

$iisApp = New-Item IIS:\Sites\$iisAppSite\$iisAppPath$iisAppName -physicalPath $directoryPath -type Application
Set-ItemProperty IIS:\Sites\$iisAppSite\$iisAppPath$iisAppName -Name applicationPool -Value $iisAppPoolName