# wkl_hu3_router_service

Esse modulo instala e configura o microserviço router_service da sigla HU3, que tem como objetivo disponibilizar os serviços de captura digital de Rede para clientes.

#### Table of Contents

1. [Description](#description)
2. [Setup - The basics of getting started with wkl_hu3_router_service](#setup)
    * [What wkl_hu3_router_service affects](#what-wkl_hu3_router_service-affects)
    * [Setup requirements](#setup-requirements)
    * [Beginning with wkl_hu3_router_service](#beginning-with-wkl_hu3_router_service)
3. [Usage - Configuration options and additional functionality](#usage)
4. [Reference - An under-the-hood peek at what the module is doing and how](#reference)
5. [Limitations - OS compatibility, etc.](#limitations)
6. [Development - Guide for contributing to the module](#development)

## Descrição

Solução única em pagamentos digitais, contendo todos os produtos e-commerce da Rede em uma única integração e única autenticação, gerando maior conversão de vendas com menor charge back.

## Setup

### O que wkl_hu3_router_service afeta

* Indisponibiliza o acesso no EC, uma vez que os serviços como autenticação e integração está na frente do EC.


### Dependências

* Red Hat 7.3+
* java 1.8
* module 'java_ks' (https://forge.puppet.com/puppetlabs/java_ks)

## Limitações

* Em caso de falha irá impactar o EC (Geração do token do PV)

## Pontos de atenção

* No ambiente de Produção possui uma API que está (exposta), acessível à partir da Rede-CORP e Rede-DEV.
Hoje não podemos fazer o bloqueio para essa API, devido o pessoal do banco Itaú poderem acessar