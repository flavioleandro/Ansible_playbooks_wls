Manifesto criado para adicionar o ip e hostname do servidor no arquivo /etc/hosts

Altera a ultima linha do arquivo /etc/hosts com as variáveis do facter do puppet referentes à ipaddress, hostname e fqdn