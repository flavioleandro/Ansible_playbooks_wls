#
# Cookbook Name:: user_manager
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
