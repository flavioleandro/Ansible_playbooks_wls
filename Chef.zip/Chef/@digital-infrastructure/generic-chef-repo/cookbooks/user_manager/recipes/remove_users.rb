data_bag('users').each do |user|
  user_data = data_bag_item('users', user)
  id = user_data['id']
  home = user_data['home']

  user id do
    action :remove
  end

  execute 'remove_home_dir' do
    command "rm -rf #{home}"
    action :run
  end
end
