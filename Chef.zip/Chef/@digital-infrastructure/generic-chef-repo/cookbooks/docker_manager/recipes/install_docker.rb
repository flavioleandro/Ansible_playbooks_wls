yum_package 'docker' do
  action :install
end
