remote_file '/opt/nimsoft-robot.x86_64.rpm' do
  source 'http://10.40.40.70:8080/setupFiles/nimsoft-robot.x86_64.rpm'
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

execute 'install_nimsoft' do
  command 'yum install -y nimsoft-robot.x86_64.rpm'
  cwd '/opt'
  action :run
end