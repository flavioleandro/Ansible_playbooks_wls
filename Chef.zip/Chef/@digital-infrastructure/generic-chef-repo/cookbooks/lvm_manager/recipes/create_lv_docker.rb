lvm_volume_group 'VG_APP' do
  physical_volumes '/dev/sdb1'

  logical_volume 'lv_docker' do
    size        '80G'
    filesystem  'btrfs'
    mount_point location: '/var/lib/docker'
  end
end
