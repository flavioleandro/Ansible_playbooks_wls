require 'spec_helper'
describe 'wget' do
  context 'with default values for all parameters' do
    it { should contain_class('wget') }
  end
end
