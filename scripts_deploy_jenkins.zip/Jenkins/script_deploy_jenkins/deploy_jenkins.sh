#!/bin/bash

path_dominio="/u01/oracle/middleware/domains/testeDom";
path_binario="/u01/oracle/middleware/wlserver_10.3";
path_console="t3://10.182.248.104:7001";

pacote=$(echo  $1);
target=$(echo $2);
usuario=$(echo $3);
senha=$(echo $4);
Cdata=$(date +%d_%b_%Y_%H_%M_%S);

if [ ! -f "$pacote" ]; then
	echo "caminho do pacote inválido, favor verifique.";
	exit;
fi

cp -p "$pacote" "$pacote"_$Cdata;
if [ ! -f "$pacote"_$Cdata  ]; then
	echo "Não foi possível validar o backup do arquivo : "$pacote"_BKP, favor verifique.";
	exit;
fi

if [ -z $target ]; then
	echo "Target não informado, favor verifique.";
	exit;
fi

deploy=$(echo $pacote |awk -F "/" '{ print $NF }' |cut -d"." -f1)

cd $path_dominio/bin/
. ./setDomainEnv.sh

java -cp $path_binario/server/lib/weblogic.jar weblogic.WLST /u01/oracle/scripts/deploy.py -u jenkins -p C!elo_2017 -a $path_console -n $deploy -f "$pacote" -t $target
