#!/bin/bash
#Author: Flavio Leandro

HOST=${1:?host}
PORT=${2:?port}
DATABASE=${3:?database}
PASSWORD=${4:?password}
if test "$DATABASE" == "HSQLDB"
then DATASOURCE="wcsitesHSQL"
else DATASOURCE="wcsitesDS"
fi
sed \
 -e "s/oracle\.wcsites\.examples=.*/oracle.wcsites.examples=false/" \
 -e "s/oracle\.wcsites\.examples\.avisports=.*/oracle.wcsites.examples.avisports=false/" \
 -e "s/oracle\.wcsites\.examples\.fsii=.*/oracle.wcsites.examples.fsii=false/" \
 -e "s/oracle\.wcsites\.examples\.Samples=.*/oracle.wcsites.examples.Samples=false/" \
 -e "s/oracle\.wcsites\.shared=.*/oracle.wcsites.shared=\/cms\/delivery\/shared/" \
 -e "s/bootstrap\.status=.*/bootstrap.status=never_done/" \
 -e "s/database\.type=.*/database.type=$DATABASE/" \
 -e "s/database\.datasource=.*/database.datasource=$DATASOURCE/" \
 -e "s/wcsites\.hostname=.*/wcsites\.hostname=$HOST/" \
 -e "s/wcsites\.portnumber=.*/wcsites\.portnumber=$PORT/" \
 -e "s/cas\.portnumber=.*/cas\.portnumber=$PORT/" \
 -e "s/cas\.hostname=.*/cas\.hostname=$HOST/" \
 -e "s/cas\.hostnameActual=.*/cas\.hostnameActual=$HOST/" \
 -e "s/cas\.hostnameLocal=.*/cas\.hostnameLocal=$HOST/" \
 -e "s/cas\.portnumberLocal=.*/cas\.portnumberLocal=$PORT/" \
 -e "s/password=.*/password=$PASSWORD/" \
 -e "s/admin.user=.*/admin.user=ContentServer/" \
 -e "s/satellite.user=.*/satellite.user=SatelliteServer/" \
 -e "s/app.user=.*/app.user=fwadmin/" \
 </app/oracle/domains/PRD_DLV/wcsites/wcsites/config/wcs_properties_bootstrap.ini \
 >/app/oracle/domains/PRD_DLV/wcsites/wcsites/config/wcs_properties_bootstrap_tmp.ini \
&& mv /app/oracle/domains/PRD_DLV/wcsites/wcsites/config/wcs_properties_bootstrap_tmp.ini \
/app/oracle/domains/PRD_DLV/wcsites/wcsites/config/wcs_properties_bootstrap.ini
