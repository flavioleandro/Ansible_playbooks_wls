#!/bin/bash
#Author: Alessandro Souza -  DevOps -  alessandro.souza@globalhitss.com.br
#Autoscaling called by DynaTrace.


#export proxy to use internet
export http_proxy=http://192.168.50.13:3128
export https_proxy=http://192.168.50.13:3128

#Check if any parameter has been passed

if [ $# -lt 1 ]; then
   echo -e "\e[01;31mFavor passar corretamente os parametros\n\e[0m"
   exit 1
fi

#check if enviroment parameter has been passed

if [ "$1" != "prod_app_ebt" ] && [ "$1" != "prod_dmz_ebt" ] ; then
       echo -e "\e[01;31mVocê precisa especificar um ambiente\n\e[0m"
       exit 1
fi

#check parameter has been passed to change filter in aws command.

if [ "$1" == "prod_app_ebt" ] ; then 
    FILTER="prod_app_ebt.json"
elif [ "$1" == "prod_dmz_ebt" ] ; then
    FILTER="prod_dmz_ebt.json"
fi

#connect on aws to retrieve instance data.
echo -e "Conectando a aws para baixar as rotas da $1\n"
aws ec2 describe-instances --region us-east-1 --filters file://filters/"$FILTER" |  jq -r   ".Reservations[] | .Instances[] | .PrivateIpAddress" > tmp/ips.txt

#Get last Ip used on subnet to add new machine
echo -e "Recuperando ultimo Ip da Subnet $1\n"
LASTIP=$(sort tmp/ips.txt | tail -n1)
echo -e "Encontrado: $LASTIP\n"

#add new ip to machine , get last ip and add +1

nextip(){
    IP=$1
    IP_HEX=$(printf '%.2X%.2X%.2X%.2X\n' `echo $IP | sed -e 's/\./ /g'`)
    NEXT_IP_HEX=$(printf %.8X `echo $(( 0x$IP_HEX + 1 ))`)
    NEXT_IP=$(printf '%d.%d.%d.%d\n' `echo $NEXT_IP_HEX | sed -r 's/(..)/0x\1 /g'`)
    echo "$NEXT_IP"
}

NUM=1
IP=$LASTIP
for i in $(seq 1 $NUM); do
   NEXTIP=$(nextip $IP)
done
echo -e "A nova maquina da subnet $1 será: $NEXTIP\n"

#check if has been passed parameter two

if [ "$2" != "create" ] && [ "$2" != "delete" ] ; then
        echo -e "\e[01;31mO Parametro 2 deve ser : create ou delete\n\e[0m"
        exit 1
fi

#Check if parameter two is equal to create machine on aws.
echo -e "Criando nova máquina na aws:\n"
sleep 1
echo -e "adicionando nova máquina no Load Balancer:\n"
if [ "$2" == "create" ] ; then
       sh bin/add-prod_dmz_ebt.sh "$NEXTIP"
       echo -e "Comando executado com sucesso\n"
       echo -e "Id: $(cat tmp/instance.txt)"
fi

