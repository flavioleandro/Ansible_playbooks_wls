#Author: Alessandro Souza - DevOps
#Start Weblogic Managed Server

import os
import re

connect('weblogic',sys.argv[4],'t3://'+sys.argv[1]+':7001')
start(sys.argv[2],'Server')

exit()