#!/bin/bash
#Author: Flavio Leandro - DevOps
# Run wlst to create a new Machine and new Managed server on cluster.

adminHost=$(cat /app/install/base-cluster/adminHost.txt)
remoteHost=$(cat /app/install/base-cluster/remoteHost.txt)
NAME_REMOTE_HOST=$(hostname)
USER=${1:-weblogic}
PASS_WLS=$(cat /app/install/base-cluster/password.txt)

#echo ${1}

/app/oracle/Middleware/Oracle_Home/oracle_common/common/bin/wlst.sh /app/install/cluster.py "$USER" "$PASS_WLS" "$NAME_REMOTE_HOST" "$adminHost" "$remoteHost"
