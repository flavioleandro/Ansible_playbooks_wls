#!/bin/bash
#Created by Alessandro Souza
#Export JAVA OPTIONS before start managed server.

JAVA_OPTIONS="-server -Xms10240m -Xmx10240m -Djava.security.egd=file:/dev/./urandom -Dweblogic.Stdout=/app/oracle/domains/csDomainDLV/servers/$(cat base-cluster/webcenter_node.txt)/logs/$(cat base-cluster/webcenter_node.txt).out -Dsites.node=$(cat base-cluster/webcenter_node.txt)"
export JAVA_OPTIONS=$JAVA_OPTIONS
 

