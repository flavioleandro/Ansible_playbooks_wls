lvm_volume_group 'VG_APP' do
  physical_volumes '/dev/sdb1'

  logical_volume 'lv_redis' do
    size        '299999M'
    filesystem  'xfs'
    mount_point location: '/redis'
  end
end