require 'spec_helper'
describe 'wf_consumer' do
  context 'with default values for all parameters' do
    it { should contain_class('wf_consumer') }
  end
end
