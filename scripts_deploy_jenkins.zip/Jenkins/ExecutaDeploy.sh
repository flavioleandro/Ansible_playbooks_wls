#!/bin/bash
## BKP do pacote antes do deploy 
##Necessário colocar timestamp

cp -p /finsys/domains/finDomain/servers/finAdm/upload/PlataformaFinanciamento.ear /finsys/domains/finDomain/servers/finAdm/upload/PlataformaFinanciamento.ear_BKP

##Setando variáveis antes do deploy
cd /finsys/domains/finDomain/bin/
. ./setDomainEnv.sh

##Chamar script de deploy

java -cp /finsys/wls_10.3.6/wlserver_10.3/server/lib/weblogic.jar weblogic.WLST deploy.py -u usuario -p senhaconsole -a t3://10.80.50.21:7777 -n  appname -f "/finsys/domains/finDomain/servers/finAdm/upload/PlataformaFinanciamento.ear" -t target 




