#Author: Flavio Leandro - Devops
# Get all servers running on webcenter sites enviroment. This servers will be separated by comma to be added to cluster json file.
import os
import re
connect(sys.argv[1],sys.argv[2],'t3://'+sys.argv[3]+':7001')
cd('/')

current_server=''
new_server=''

listofservers = open('/app/install/base-cluster/servers.txt', 'w')

servers = cmo.getServers()
for s in servers:
    name = s.getName()
    port = s.getListenPort();
    if name != 'AdminServer':
        if ref != None:
           listofservers.write(name+',')
listofservers.close()

infile = open('/app/install/base-cluster/servers.txt', 'r')
target = open('/app/install/base-cluster/list.txt','w')
firstLine = infile.readline()
target.write(firstLine.rstrip(','))
infile.close()
target.close()
os.remove('/app/install/base-cluster/servers.txt')
