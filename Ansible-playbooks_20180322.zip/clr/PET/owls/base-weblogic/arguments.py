import os
import re
connect('weblogic',sys.argv[1],'t3://localhost:7001')

edit()
startEdit()

cd('/')
cd('/Servers/server1/ServerStart/server1')
cmo.setArguments('-server -Xms4G -Xmx4G -Djava.security.egd=file:/dev/./urandom -Dsites.node=server1')
activate()
exit()
