require 'spec_helper'
describe 'paas' do
  context 'with default values for all parameters' do
    it { should contain_class('paas') }
  end
end
