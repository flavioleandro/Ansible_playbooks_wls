require 'spec_helper'

describe 'infra_ldap::install' do
  on_supported_os.each do |os, os_facts|
    context "on #{os}" do
      let(:facts) { os_facts }

      it { is_expected.to contain_package('nss-pam-ldapd').with('ensure' => 'present') }
      it { is_expected.to contain_package('krb5-workstation').with('ensure' => 'present') }
      it { is_expected.to contain_package('pam_krb5').with('ensure' => 'present') }
      it { is_expected.to contain_package('nscd').with('ensure' => 'present') }
      it { is_expected.to contain_package('openldap-clients').with('ensure' => 'present') }
    end
  end
end
