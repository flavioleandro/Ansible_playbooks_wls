#!/bin/bash
#Author: Flavio Leandro -  DevOps
USER=${1:-weblogic}
PASS=$(cat /app/install/base-owls/password.txt)
HOST=$(cat /app/install/base-owls/host.txt)

#begin start Managed Server
echo "****" Starting Managed Server
mkdir -p /app/oracle/logs
touch /app/oracle/logs/server_01.log
nohup /app/oracle/domains/PET_CAD/bin/startManagedWebLogic.sh server_01 t3://"$(cat /app/install/base-owls/host.txt)":7001 >/app/oracle/logs/server_01.log &
#nohup /app/oracle/domains/PET_CAD/bin/startManagedWebLogic.sh server_01 t3://$HOST:7001 >/app/oracle/logs/server_01.log &
perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/server_01.log
#rm -rf /app/install

#begin start WebLogic
#echo "****" Starting weblogic
#mkdir -p /app/oracle/logs
#touch /app/oracle/logs/admin.log
#nohup /app/oracle/domains/PET_CAD/bin/startWebLogic.sh > /app/oracle/logs/admin.log &
#perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/admin.log

