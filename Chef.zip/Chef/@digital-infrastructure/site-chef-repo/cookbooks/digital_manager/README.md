# Cookbook digital_manager 

Cookbook utilizado para criar receitas para a plataforma Digital do Site STAR.
As receitas deste cookbook são utilizadas através do pipeline de cada microserviço disponível no `Jenkins`.

## Requisitos

Lista de pré-requisitos para utilizar este cookbook.

### Plataformas

- RHEL 7.2
- Chef 12.0 or later.

### Cookbooks

- Nenhuma dependência.

## Atributos

Os atributos utilizados pelas receitas são os próprios arquivos .json gerados no momento de deploy.

## Chef Console

- [https://digital-chef.ccorp.local/](https://digital-chef.ccorp.local/)

## Utilização

### Receita "digital_manager::digital_yml_generate"

A receita `digital_manager::digital_yml_generate` irá gerar os arquivos .json e .yml que serão utilizados para executar o deploy dos microserviços.
Os arquivos gerados utilizam como variáveis o conteúdo da databag `microservices`

Apenas icluir `digital_manager::digital_yml_generate` no `run_list` dos hosts gerenciados pelo Chef.

```json
{
  "name":"vvcelxxxxx",
  "run_list": [
    "recipe[digital_manager::digital_yml_generate]"
  ]
}
```

### Receita "digital_manager::digital_deploy"

A receita `digital_manager::digital_deploy` irá executar os procedimentos de deploy de novos microserviços.

Apenas icluir `digital_manager::digital_deploy` no `run_list` dos hosts gerenciados pelo Chef.

```json
{
  "name":"vvcelxxxxx",
  "run_list": [
    "recipe[digital_manager::digital_deploy]"
  ]
}
```

> Atenção: A receita `digital_manager::digital_deploy` deverá ser executada apenas após a execução da receita `digital_manager::digital_yml_generate`

# Contribuidores

- Fabio G. Martins (fabio.martins@cielo.com.br)

