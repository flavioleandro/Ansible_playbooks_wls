cp C:/bea10/user_projects/domains/col_domain/servers/AdminServer/stage/ConsultaDadosCadastrais-1/ConsultaDadosCadastrais-1.0.0-SNAPSHOT.war C:/Users/jjesus/Desktop/TesteBackup/
java weblogic.Deployer -adminurl t3://localhost:7001 -username weblogic -password weblogic -undeploy -name ConsultaDadosCadastrais-1 -targets AdminServer
rm -rf C:/bea10/user_projects/domains/col_domain/servers/AdminServer/stage/
java weblogic.Deployer -adminurl t3://localhost:7001 -username weblogic -password weblogic -deploy -name ConsultaDadosCadastrais-1 -targets AdminServer -source C:/branch_final_externalizacao/PortalCBMP/portlets/ConsultaDadosCadastrais/target/ConsultaDadosCadastrais-1.0.0-SNAPSHOT.war
sleep 60

