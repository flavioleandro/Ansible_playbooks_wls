#!/bin/bash
#Author: Flavio Leandro -  DevOps
USER=${1:-weblogic}
PASS=$(cat /app/install/base-cluster/password.txt)
HOST=$(cat /app/install/base-cluster/host.txt)

#nohup /app/oracle/domains/WCP_Domain/bin/startNodeManager.sh &
#star managed server of webcenter sitesss
echo "****" Starting API Managed Server
touch /app/oracle/logs/api.log
#nohup /app/oracle/domains/API_Domain/bin/startManagedWebLogic.sh API t3://$HOST:7001 >/app/oracle/logs/api.log
#perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/wcportal.log
#rm -rf /app/install

. /app/oracle/Middleware/Oracle_Home/wlserver/server/bin/setWLSEnv.sh

java weblogic.WLST /app/install/base-cluster/start_stop_managedservers.py -p /app/install/base-cluster/myDomain-cluster.properties
