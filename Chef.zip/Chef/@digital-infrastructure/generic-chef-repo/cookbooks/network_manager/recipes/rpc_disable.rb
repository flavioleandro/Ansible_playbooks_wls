service 'rpcbind.service' do
  action [:stop, :disable]
end
