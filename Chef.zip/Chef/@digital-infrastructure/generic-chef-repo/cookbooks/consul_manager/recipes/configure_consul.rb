directory '/etc/consul.d/bootstrap' do
  owner 'root'
  group 'root'
  mode '0755'
  recursive true
  action :create
end

template '/etc/consul.d/bootstrap/config.json' do
  source 'etc/consul.d/bootstrap/config.json.erb'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

consul_path = ''

if (node.chef_environment == 'consul') || (node.chef_environment == 'consul-prd')
  consul_path = 'server'
else
  consul_path = 'client'
end

unless consul_path.nil? || consul_path == ''

  directory "/etc/consul.d/#{consul_path}" do
    owner 'root'
    group 'root'
    mode '0755'
    recursive true
    action :create
  end

  # hostname = node['hostname']
  #ip_addr = node['ipaddress']

  template "/etc/consul.d/#{consul_path}/config.json" do
    source "etc/consul.d/#{consul_path}/config.json.erb"
    owner 'root'
    group 'root'
    mode '0644'
    variables(
      ip_addr: node['ipaddress']
    )
    action :create
  end

end

template '/usr/lib/systemd/system/consul.service' do
  source 'usr/lib/systemd/system/consul.service.erb'
  owner 'root'
  group 'root'
  mode '0644'
  variables(
    consul_path: consul_path
  )
  action :create
end

execute 'systemctl_reload' do
  command 'systemctl daemon-reload'
  action :run
end
