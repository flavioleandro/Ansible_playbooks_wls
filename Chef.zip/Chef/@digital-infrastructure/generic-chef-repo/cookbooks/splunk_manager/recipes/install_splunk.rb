remote_file '/opt/splunk-6.5.0-59c8927def0f-linux-2.6-x86_64.rpm' do
  source 'https://www.splunk.com/bin/splunk/DownloadActivityServlet?architecture=x86_64&platform=linux&version=6.5.0&product=splunk&filename=splunk-6.5.0-59c8927def0f-linux-2.6-x86_64.rpm&wget=true'
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

execute 'install_splunk' do
  command 'rpm -i --prefix=/splunk splunk-6.5.0-59c8927def0f-linux-2.6-x86_64.rpm'
  cwd '/opt'
  action :run
end