microservice = ENV['SERVICE_NAME']
Chef::Log.warn("Executing restart of microservice: #{microservice}")

execute 'microservice_restart' do
  cwd '/home/microservice/docker/compose/'
  command "sudo -H -u microservice bash -c '/usr/local/bin/docker-compose -f digital.yml up -d --force-recreate #{microservice}'"
  action :run
end
