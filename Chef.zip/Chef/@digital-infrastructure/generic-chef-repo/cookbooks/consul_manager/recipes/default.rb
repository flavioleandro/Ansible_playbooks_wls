#
# Cookbook Name:: consul_manager
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

include_recipe 'consul_manager::install_consul'
include_recipe 'consul_manager::configure_consul'
