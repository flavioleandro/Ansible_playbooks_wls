#!/bin/bash
#Author: Alessandro Souza - DevOps -  alessandro.souza@globalhitss.com.br

IP=$(ifconfig eth0 | awk '/inet addr/{print substr($2,6)}')

HOSTNAME=$(hostname)
URL_DLV="cms.owcs.pet"
echo $IP $URL_DLV >> /etc/hosts

runuser -l oracle -c 'ansible-playbook /home/oracle/owcs-cluster/InstallSites.yml'

IPMULTICAST="10.10."$(echo $IP | cut -c9-13)
edge -l $(cat /home/oracle/owcs-cluster/base-cluster/superNode.txt) -c Intershop -a $IPMULTICAST -E
sleep 3
route add -net 230.0.0.0 netmask  255.255.255.255  dev edge0

apachectl start

# Delete me
#rm $0
