## API host configurado no 'Default Attributes' de cada 'Environment'
active_profile = node['ACTIVE_PROFILE']
consul_host = node['CONSUL_HOST']
consul_port = node['CONSUL_PORT']
api_host = node['apiHost']
osb_url = node['osbUrl']
cache_url = node['cacheUrl']
cache_port = node['cachePort']
cache_password = node['cachePassword']
ldap_urls = node['ldapUrls']
ldap_user_dn = node['ldapUserDn']
ldap_password = node['ldapPassword']

service_name = ENV['SERVICE_NAME']

Chef::Log.warn("Service Name: #{service_name}")

microservice_data = data_bag_item('microservices', service_name)
microservice_name = microservice_data['id']
image = microservice_data['image']
version = microservice_data['version']
port = microservice_data['port']
log_level = if microservice_data['log_level'].nil? || microservice_data['log_level'].empty?
              'INFO'
            else
              microservice_data['log_level']
            end

# Gerando diretório para armazenar os arquivos de configuração de cada microservice
directory '/home/microservice/docker/compose/microservices' do
  owner 'microservice'
  group 'microservice'
  mode '0755'
  action :create
  recursive true
end

# Gerando arquivo de log
cookbook_file "/home/microservice/log4j/#{microservice_name}-log4j2.xml" do
  source 'log4j2.xml'
  owner 'microservice'
  group 'microservice'
  mode '0644'
  action :create
end

# Gerando arquivos .yml que serão utilizados para gerar o arquivo digital.yml
template "/home/microservice/docker/compose/microservices/#{microservice_name}.yml" do
  source 'microservice.yml.erb'
  owner 'microservice'
  group 'microservice'
  mode '0644'
  variables(
    microservice: microservice_name,
    image: image,
    version: version,
    active_profile: active_profile,
    consul_host: consul_host,
    consul_port: consul_port,
    api_host: api_host,
    port: port,
    osb_url: osb_url,
    cache_url: cache_url,
    cache_port: cache_port,
    cache_password: cache_password,
    ldap_urls: ldap_urls,
    ldap_user_dn: ldap_user_dn,
    ldap_password: ldap_password,
    splunk_host: node['ipaddress'],
    splunk_port: '8514',
    host_ip: node['ipaddress'],
    log_level: log_level
  )
  action :create
end

# Gerando arquivos .json que serão utilizados pelo Chef como 
# variáveis de ambiente durante o deploy
template "/home/microservice/docker/compose/microservices/#{microservice_name}.json" do
  source 'microservice.json.erb'
  owner 'microservice'
  group 'microservice'
  mode '0644'
  variables(
    microservice: microservice_name,
    image: image,
    version: version,
    active_profile: active_profile,
    consul_host: consul_host,
    consul_port: consul_port,
    api_host: api_host,
    osb_url: osb_url,
    cache_url: cache_url,
    cache_port: cache_port,
    cache_password: cache_password,
    ldap_urls: ldap_urls,
    ldap_user_dn: ldap_user_dn,
    ldap_password: ldap_password,
    port: port
  )
  action :create
end

# Gerando arquivo digital.yml
execute 'generate_digital_yml' do
  user 'microservice'
  group 'microservice'
  cwd '/home/microservice/docker/compose/'
  command 'cat microservices/*.yml > digital.yml'
  action :run
end
