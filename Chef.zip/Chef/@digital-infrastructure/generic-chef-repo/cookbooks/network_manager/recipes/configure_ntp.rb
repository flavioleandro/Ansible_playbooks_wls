cookbook_file '/etc/ntp.conf' do
  source 'etc/ntp.conf'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

service 'ntpd' do
  supports status: true, restart: true, reload: true
  action [:enable, :restart]
end