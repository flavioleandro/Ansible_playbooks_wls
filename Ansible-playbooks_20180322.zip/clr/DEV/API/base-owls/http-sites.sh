#!/bin/bash
#Author: Flavio Leandro
while ! curl http://$(cat /app/install/base-owcs/apache.txt):9001/sites/HelloCS | grep Success
do sleep 1 ; done
curl http://$(cat /app/install/base-owcs/apache.txt):9001/sites/sitesconfig
