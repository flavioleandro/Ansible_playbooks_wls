execute 'configure_splunk' do
  command "./splunk start --accept-license"
    cwd '/opt'
  action :run
end

execute 'enable-splunk' do
  command './splunk enable boot-start'
    cwd '/opt'
  action :run
end