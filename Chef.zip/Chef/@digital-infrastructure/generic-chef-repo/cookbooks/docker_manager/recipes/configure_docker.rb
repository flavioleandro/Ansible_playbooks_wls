cookbook_file '/etc/sysconfig/docker-network' do
  source 'sysconfig/docker-network'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

cookbook_file '/etc/sysconfig/docker' do
  source 'sysconfig/docker'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

group 'docker' do
  action :create
end

data_bag('users').each do |user|
  user_data = data_bag_item('users', user)
  id = user_data['id']

  group 'docker' do
    members id
    append true
    action :modify
    only_if "grep #{id} /etc/passwd"
  end
end

execute 'service_reload' do
  command 'systemctl daemon-reload'
  action :run
end

service 'docker' do
  supports status: true, restart: true, reload: true
  action [:enable, :restart]
end
