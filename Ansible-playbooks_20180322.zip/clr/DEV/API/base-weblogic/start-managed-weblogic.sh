#!/bin/bash
#Author: Flavio Leandro -  DevOps
USER=${1:-weblogic}
PASS=$(cat /app/install/base-owls/password.txt)
HOST=$(cat /app/install/base-owls/host.txt)

#nohup /app/oracle/domains/WCP_Domain/bin/startNodeManager.sh &
#star managed server of webcenter sitesss
echo "****" Starting managed WebCenter Portal
touch /app/oracle/logs/api.log
#nohup /app/oracle/domains/DEV_CAD/bin/startManagedWebLogic.sh API t3://$HOST:7001 >/app/oracle/logs/api.log
#perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/wcportal.log
#rm -rf /app/install

. /app/oracle/middleware/wlserver/server/bin/setWLSEnv.sh

nohup /app/oracle/domains/DEV_CAD/bin/startManagedWebLogic.sh API t3://$HOST:7001 >/app/oracle/logs/api.log &

#java weblogic.WLST /app/install/start_stop_managedservers.py stop $(cat /app/install/base-owls/host.txt)

#java weblogic.WLST /app/install/start_stop_managedservers.py start $(cat /app/install/base-owls/host.txt)
