#!/bin/bash
#Author: Flavio Leandro- DevOps
#Start Weblogic in the new machine
echo "****" Starting NodeManager
nohup /app/oracle/domains/WCP_Domain/bin/startNodeManager.sh &
#star managed server of webcenter sitesss
echo "****" Starting managed Webcenter Portal
mkdir -p /app/oracle/logs/
touch /app/oracle/logs/wcpportal2.log
#mkdir -p /cms/delivery/config
#cp /app/oracle/domains/PRD_DLV/wcsites/wcsites/config/wcs_properties.json /cms/delivery/config
mkdir -p /app/oracle/domains/WCP_Domain/servers/$(cat /app/install/base-cluster/hostname.txt)/security
cp -R /app/oracle/domains/WCP_Domain/servers/AdminServer/security/boot.properties /app/oracle/domains/WCP_Domain/servers/$(cat /app/install/base-cluster/hostname.txt)/security

. /app/oracle/Middleware/Oracle_Home/wlserver/server/bin/setWLSEnv.sh

java weblogic.WLST /app/install/base-cluster/start_stop_managedservers.py stop $(cat /app/install/base-cluster/hostname.txt)

java weblogic.WLST /app/install/base-cluster/start_stop_managedservers.py start $(cat /app/install/base-cluster/hostname.txt)

#nohup /app/oracle/domains/WCP_Domain/bin/startManagedWebLogic.sh $(cat /app/install/base-cluster/hostname.txt) t3://$(cat /app/install/base-cluster/adminHost.txt):7001 > /app/oracle/logs/wcportal.out &
#perl /app/install/tailuntil.pl RUNNING /app/oracle/logs/wcportal.out
