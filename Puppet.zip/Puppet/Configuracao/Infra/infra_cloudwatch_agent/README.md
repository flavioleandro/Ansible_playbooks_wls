# infra_cloudwatch_agent

1. [Descrição](#description)
2. [Setup](#setup)
    * [O que o modulo afeta](#o-que-infra_cloudwatch_agent-afeta)
    * [Requisitos](#requisitos)
    * [Iniciando](#basico-infra_cloudwatch_agent)
3. [Exemplos](#exemplos)
4. [Limitações](#limitações)

## Description

Esse modulo instala e configura o agente do CloudWatch Logs; esse modulo tem como objetivo principal monitorar os logs das aplicações da redecard.

## Setup

### O que infra_cloudwatch_agent afeta

Arquivos de configuração e diretorios (criados pelo modulo)

* /opt/aws/*
* /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json (arquivo de configuração gerenciado pelo modulo)

### Requisitos 

AWS SSM Agent 

### Basico infra_cloudwatch_agent

Para iniciar a monitoração dos logs de aplicação, declare a classe do infra_cloudwatch_agent e passe os seguintes parametros dentro de uma hash table 'logs':



    file_path                > Especifica o path absoluto do log que será monitorado.
    multi_line_start_pattern > Especifica o padrão para identificar o início de uma mensagem de log.
    timestamp_format         > Especifica como o carimbo de data e hora é extraído de logs.
    log_group_name           > Especifica o grupo de logs de destino.
    
Para mais detalhes, veja a documentação oficial da aws:
https://docs.aws.amazon.com/pt_br/AmazonCloudWatch/latest/logs/AgentReference.html

## Exemplos

Situação 1:
Monitorar o arquivo '/opt/WT/customer-microservice/log/customer.log' e o arquivo '/opt/WT/integrator-microservice/log/integrator.log'

``` puppet
class wkl_xpto {

  class { 'infra_cloudwatch_agent':
    logs => [
     {
       file_path => '/opt/WT/customer-microservice/log/customer.log',
       multi_line_start_pattern => '[w+ s?] w{4}w{2} w{2}',
       timestamp_format => '%Y-%m-%d %H:%M:%S',
       log_group_name => '/wt/customer'
     },
     {
       file_path => '/opt/WT/integrator-microservice/log/integrator.log',
       multi_line_start_pattern => '[w+ s?] w{4}w{2} w{2}',
       timestamp_format => '%Y-%m-%d %H:%M:%S',
       log_group_name => '/wt/integrator'
     }
    ]
  }

}
```

Situação 2:
Monitorar o arquivo '/opt/HU3/logs/router-service.log'

``` puppet
class wkl_xpto {

  class { 'infra_cloudwatch_agent':
    logs => [
     {
       file_path => '/opt/HU3/logs/router-service.log',
       multi_line_start_pattern => '[w+ s?] w{4}w{2} w{2}',
       timestamp_format => '%Y-%m-%d %H:%M:%S',
       log_group_name => '/hu3/router-service'
     }
    ]
  }

}
```

## Limitações

Esse modulo não pode ser declarado diretamente na console do puppet.

Esse modulo não pode ser declarado duas vezes, por modulos diferentes, aplicando no mesmo server. 

Esse modulo não suporte Windows Server por enquanto.
