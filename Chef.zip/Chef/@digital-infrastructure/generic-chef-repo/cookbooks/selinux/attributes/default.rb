default['selinux']['state'] = 'enforcing'
default['selinux']['booleans'] = {}
