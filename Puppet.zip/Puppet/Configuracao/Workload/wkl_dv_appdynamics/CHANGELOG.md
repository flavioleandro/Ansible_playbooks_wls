## [1.0.0](https://github.com/kinneygroup/puppet-module-appdynamics/releases/tag/v1.0.0) (2017-02-06)
### Summary

Initial stable release

#### Features
- Controller installation.

#### Bugfixes
- N/A
