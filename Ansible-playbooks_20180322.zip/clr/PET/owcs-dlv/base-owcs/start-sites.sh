#!/bin/bash
nohup /app/oracle/domains/PET_DLV/bin/startNodeManager.sh &
nohup /app/oracle/domains/PET_DLV/bin/startManagedWebLogic.sh wcsites_server1 t3://"$(cat /app/install/base-owcs/host.txt)":7001 >/app/oracle/logs/sites.log &
