data_bag('users_middleware').each do |user|
  user_data = data_bag_item('users_middleware', user)
  id = user_data['id']
  name = user_data['name']
  home = user_data['home']

  user id do
    comment name
    home home
    shell '/bin/bash'
    password 'cielo@123'
  end

  group 'wheel' do
    members id
    append true
    action :modify
  end

  execute 'chown_home' do |home
    command "chown -R #{id}. #{home}"
    action :run
  end
end
