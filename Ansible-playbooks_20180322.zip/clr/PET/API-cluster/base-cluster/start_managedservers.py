import time
import getopt
import sys
import re

# Get location of the properties file.
properties = ''
try:
   opts, args = getopt.getopt(sys.argv[1:],"p:h::",["properies="])
except getopt.GetoptError:
   print 'config-weblogic.py -p <path-to-properties-file>'
   sys.exit(2)
for opt, arg in opts:
   if opt == '-h':
      print 'config-weblogic.py -p <path-to-properties-file>'
      sys.exit()
   elif opt in ("-p", "--properties"):
      properties = arg
print 'properties=', properties

# Load the properties from the properties file.
from java.io import FileInputStream

propInputStream = FileInputStream(properties)
configProps = Properties()
configProps.load(propInputStream)

# Set all variables from values in properties file.

adminusername=configProps.get("adminusername")
adminpassword=configProps.get("adminpassword")
adminurl=configProps.get("adminurl")

print 'adminUsername=', adminusername
print 'adminPassword=', adminpassword
print 'adminURL=', adminurl

# Connect to the AdminServer.
connect(adminusername, adminpassword, adminurl)

print "** Starting API Server **"
start(name="API", block="true")

exit()
