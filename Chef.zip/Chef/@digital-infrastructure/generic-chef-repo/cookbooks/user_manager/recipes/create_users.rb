data_bag('users').each do |user|
  user_data = data_bag_item('users', user)
  id = user_data['id']
  name = user_data['name']
  home = user_data['home']

  user id do
    comment name
    home home
    shell '/bin/bash'
    password 'Cielo123'
  end

  group 'wheel' do
    members id
    append true
    action :modify
  end

  execute 'chown_home' do
    command "chown -R #{id}. #{home}"
    action :run
  end
end
