Import-Module WebAdministration
$iisAppPoolName = "erede.api"
$iisAppPoolDotNetVersion = "v4.0"
$iisAppName = "erede.api"
$directoryPath = "D:\inetpub\WWWRoot\Siglas\EC\erede.api\"

If (!(Test-Path $directoryPath)) {
    mkdir $directoryPath
    }

cd IIS:\AppPools\

if (!(Test-Path $iisAppPoolName -pathType container))
{
    $appPool = New-Item $iisAppPoolName
    $appPool | Set-ItemProperty -Name "managedRuntimeVersion" -Value $iisAppPoolDotNetVersion
}

cd IIS:\Sites\

if (Test-Path $iisAppName -pathType container)
{
    return
}

$iisApp = New-Item $iisAppName -bindings @{protocol="http";bindingInformation=":8080:"} -physicalPath $directoryPath
$iisApp | Set-ItemProperty -Name "applicationPool" -Value $iisAppPoolName