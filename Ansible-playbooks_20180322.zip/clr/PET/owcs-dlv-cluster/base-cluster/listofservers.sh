#!/bin/bash
#Author: Flavio Leandro - DevOps
# Run wlst to create a new Machine and new Managed server on cluster.

ADMIN_HOST=$(cat /app/install/base-cluster/adminHost.txt)
NODEHOST=$(hostname)
USER=${1:-weblogic}
PASS_WLS=$(cat /app/install/base-cluster/password.txt)

/app/oracle/middleware/oracle_common/common/bin/wlst.sh /app/install//base-cluster/listofservers.py "$USER" "$PASS_WLS" "$ADMIN_HOST"
