#!/bin/bash
#Author: Alessandro Souza- DevOps
#Start NodeManager in the new machine

/app/oracle/domains/csDomainDLV/bin/startNodeManager.sh &
