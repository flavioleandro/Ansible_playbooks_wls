# Cielo PaaS - Repositório Puppet

O Cielo PaaS é uma iniciativa de Infra Convergente e Suporte Open que tem o intuito de entregar ambientes com aplicações instaladas e pré-configuradas, reduzindo assim o tempo de setup e entrega.

Uma das ferramentas usadas nesta solução é o [Puppet](https://pt.wikipedia.org/wiki/Puppet), que faz o papel de instalar e pré-configurar as aplicações após que o servidor é provisionado pelo VRA (VMWare Realize Automation)

## Fluxo 

1. O usuário no [Portal de Cloud](https://portalcielocloud.ccorp.local/vcac/) escolhe com quais produtos ele quer que o servidor venha instalado
		- Ele pode escolher até 3 opções
2. No final do processo de provisionar a máquina, o [VRA (VMware Realize Automation)](http://www.vmware.com/products/vrealize-automation.html) executa um script de post-install, que faz os seguintes passos:
    - Baixa o repositório do [Puppet Agent](https://docs.puppet.com/puppet/latest/man/agent.html)
    - Realiza a instalação do [Puppet Agent](https://docs.puppet.com/puppet/latest/man/agent.html)
    - Configura o [Puppet Agent](https://docs.puppet.com/puppet/latest/man/agent.html)
    - De acordo com os softwares que o usuário escolheu, o script insere um arquivo com as opções escolhidas (```/etc/puppetlabs/facts.d/role.yaml```)
        - Isso foi feito usando os [custom facts](https://docs.puppet.com/facter/3.6/custom_facts.html) do Puppet.
    - Executa o Puppet Agent
3. Quando o Puppet Agent é executado, ele inicia o processo de comunicação com o Puppet Server, enviando o seu certificado para ele
4. Enquanto este certificado não é aceito do lado do Puppet Server, o Agent não consegue realizar nenhuma ação
    - Então para que ele não fique esperando este aceite, configurei o [Auto Assign](https://docs.puppet.com/puppet/4.9/ssl_autosign.html).
5. Depois do certificado aceito, o Agent manda os seus fatos (através do [Facter](https://docs.puppet.com/facter/)) e pede o catalogo para o Puppet Server 
6. O Puppet Server inicia a compilação do catalogo:
    - Primeiro realizando a [classificação do nó](https://docs.puppet.com/puppet/4.10/lang_node_definitions.html)
        - Existem vários meios de se fazer isso, eu escolhi fazer com uma ferramenta chamada [Hiera](https://docs.puppet.com/puppet/4.9/hiera_quick.html)                
    - Com essa classificação, ele consegue definir que [manifestos](https://docs.puppet.com/puppet/4.10/lang_summary.html) devem ser compilados
    - Ao final da compilação é gerado o catalogo (que são os manifestos traduzidos para outro formato)
7. O Puppet Server transfere este catalogo para o Agent
8. O Agent executa o que está nos catalogos 

## Referências

[Docs](https://docs.puppet.com)

[Architecture Overview](https://docs.puppet.com/puppet/4.10/architecture.html)

[Language Reference](https://docs.puppet.com/puppet/4.10/lang_summary.html)

[Resource Types](https://docs.puppet.com/puppet/latest/type.html)

[Vídeos tutoriais da Instruct](https://www.youtube.com/user/InstructBR/videos)
**Empresa que presta suporte ao Puppet no Brasil**


## [R10K](https://docs.puppet.com/pe/latest/r10k.html)
É uma ferramenta que automatiza o processo de transferência de seus manifestos que estão armazenados dentro de um sistema de controle de versão (Ex.: git) para dentro do servidor do Puppet e automatiza também o download dos módulos usados por seus manifestos, descritos através do [Puppetfile](https://docs.puppet.com/pe/latest/cmgmt_puppetfile.html).

```r10k deploy```

Ou seja, esta ferramenta sincroniza o que está no git com o que vai para o servidor do Puppet.

Cada branch armazenada no git, é convertida em um environment no Puppet.

**Binário:** ```/opt/puppetlabs/bin/r10k```

**Arquivo de configuração:** ```/etc/puppetlabs/r10k/r10k.yaml```

## [Hiera](https://docs.puppet.com/puppet/4.9/hiera_quick.html)

É uma ferramenta que funciona como uma espécie de mini banco de dados, ela serve especificamente para você não precisar inserir diretamente no seus manifestos alguns tipos de dados (Ex.: diretório de algum arquivo de configuração, nome de um pacote e outras informações que podem variar de ambiente para ambiente), fazendo com que o seu manifesto seja de fato reutilizável e portável

**Binário:** ```/opt/puppetlabs/bin/hiera```

**Arquivo de configuração:** ```/etc/puppetlabs/puppet/hiera.yaml```

**Dados (diretório padrão, porém configurável):** ```/etc/puppetlabs/code/environments/production/hieradata```

## Estrutura de diretórios

- ```site```: Diretório que contém os manifestos desenvolvidos por mim
    - ```common```: Diretório com os manifestos que serão aplicados a todos os servidores do PaaS, independente da Role
    - ```paas```: Diretório com os manifestos que serão aplicados de acordo com a role escolhida no PaaS
- ```hieradata```: Diretório contendo os dados usados pelo Hiera
    - ```roles```: Diretório que contém a definição dos manifestos e fatos para cada role
    - ```common.yaml```: Diretório que contém a definição dos manifestos e fatos padrão
- ```manifests```: Diretório padrão dos manifestos
    - ```site.pp```: Manifesto padrão (o Puppet sempre compila este manifesto primeiramente)
- ```Puppetfile```: Arquivo usado como referência para o R10K baixar os módulos dependentes automaticamente
- ```environment.conf```: Arquivo usado para configurar o environment do Puppet

## Sabores (manifestos) disponíveis

Disponíveis dentro do diretório ```site```

- Apache
- Cassandra
- Consul
- Consul-Template
- Docker
- GitLab
- JBoss
- Jenkins
- MySQL
- Nexus
- PostgreSQL
- Redis
- Tomcat