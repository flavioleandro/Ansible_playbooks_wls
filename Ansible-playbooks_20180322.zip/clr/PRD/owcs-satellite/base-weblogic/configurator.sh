/app/oracle/jdk1.8.0_131/bin/java -jar /app/oracle/middleware/wcsites/satelliteserver/satellite-configurator.jar -silent /app/oracle/domains/PRD_SAT/wcsites/satelliteserver/config

