log_level                :info
log_location             STDOUT
node_name                'flaviol'
client_key               '~/Documents/Digital_cookbooks/chef-repo/.chef/flaviol.pem'
validation_client_name   'chef-validator'
#validation_key           '~/chef-repo/.chef/shortname.pem'
chef_server_url          'https://vvcelpdigche01/organizations/cielo'
#syntax_check_cache_path  '~/chef-repo/.chef/syntax_check_cache'
cookbook_path [ '~/Documents/Digital_cookbooks/chef-repo/cookbooks' ]
trusted_certs_dir        "~/Documents/Digital_cookbooks/chef-repo/.chef/trusted_certs"
ssl_verify_mode          :verify_none