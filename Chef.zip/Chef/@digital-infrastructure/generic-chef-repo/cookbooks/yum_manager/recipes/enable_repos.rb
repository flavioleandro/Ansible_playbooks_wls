execute 'enable_extra' do
  command 'yum-config-manager --enable rhel-7-server-extras-rpms'
  action :run
end
