#!/bin/bash
#Author: Flavio Leandro -  DevOps
# stop
/app/oracle/domains/PET_DLV/bin/stopManagedWebLogic.sh wcsites_server1 t3://localhost:7001
sleep 2
#altera diretorio de configuracao do sites para shared
sed -i -e 's/-Dsites.config=${DOMAIN_HOME}\/wcsites\/wcsites\/config /-Dsites.config=\/cms\/delivery\/config /g' /app/oracle/domains/PET_DLV/bin/setStartupEnv.sh
cp /app/oracle/domains/PET_DLV/wcsites/wcsites/config/wcs_properties.json /cms/delivery/config/.

#change timetolive in all files from webcenter sites configuration
#cas-cache.xml
#cs-cache.xml
#linked-cache.xml
#ss-cache.xml

sed -i -e 's/timeToLive=0"/timeToLive=1"/g' /app/oracle/domains/PET_DLV/wcsites/wcsites/config/cas-cache.xml
sed -i -e 's/timeToLive=0"/timeToLive=1"/g' /app/oracle/domains/PET_DLV/wcsites/wcsites/config/cs-cache.xml
sed -i -e 's/timeToLive=0"/timeToLive=1"/g' /app/oracle/domains/PET_DLV/wcsites/wcsites/config/linked-cache.xml
sed -i -e 's/timeToLive=0"/timeToLive=1"/g' /app/oracle/domains/PET_DLV/wcsites/wcsites/config/ss-cache.xml

#nohup /app/install/start-sites.sh &
