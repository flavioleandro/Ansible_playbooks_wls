#!/bin/bash
nohup /app/oracle/domains/WCP_Domain/bin/startNodeManager.sh &
nohup /app/oracle/domains/WCP_Domain/bin/startManagedWebLogic.sh WC_Portal t3://"$(cat /app/install/base-owls/host.txt)":7001 >/app/oracle/logs/WC_Portal.log &
