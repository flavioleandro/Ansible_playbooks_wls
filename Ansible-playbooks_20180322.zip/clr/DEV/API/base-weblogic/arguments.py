import os
import re
connect('weblogic',sys.argv[1],'t3://localhost:7001')

edit()
startEdit()

cd('/')
cd('/Servers/WCP_Domain/ServerStart/WC_Portal')
cmo.setArguments('-server -Xms4G -Xmx8G -Djava.security.egd=file:/dev/./urandom -Dsites.node=WC_Portal')
activate()
exit()
