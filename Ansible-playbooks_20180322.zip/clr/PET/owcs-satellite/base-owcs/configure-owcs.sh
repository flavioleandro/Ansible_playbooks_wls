#!/bin/bash
#Author: Flavio Leandro -  DevOps
# stop
/app/oracle/domains/PET_SAT/bin/stopManagedWebLogic.sh satellite_server1 t3://localhost:7001
sleep 2
#altera diretorio de configuracao do sites para shared
sed -i -e 's/-Dsites.config=${DOMAIN_HOME}\/wcsites\/satelliteserver\/config /-Dsites.config=\/cms\/satellite\/config /g' /app/oracle/domains/PET_SAT/bin/setStartupEnv.sh
cp /app/oracle/domains/PET_SAT/wcsites/satelliteserver/config/wcs_properties.json /cms/satellite/config/.

#change timetolive in all files from webcenter sites configuration
#cas-cache.xml
#cs-cache.xml
#linked-cache.xml
#ss-cache.xml

sed -i -e 's/timeToLive=0"/timeToLive=1"/g' /app/oracle/domains/PET_SAT/wcsites/satelliteserver/config/cas-cache.xml
sed -i -e 's/timeToLive=0"/timeToLive=1"/g' /app/oracle/domains/PET_SAT/wcsites/satelliteserver/config/cs-cache.xml
sed -i -e 's/timeToLive=0"/timeToLive=1"/g' /app/oracle/domains/PET_SAT/wcsites/satelliteserver/config/linked-cache.xml
sed -i -e 's/timeToLive=0"/timeToLive=1"/g' /app/oracle/domains/PET_SAT/wcsites/satelliteserver/config/ss-cache.xml

#nohup /app/install/start-sites.sh &
