﻿Import-Module WebAdministration
$iisAppSite = "erede.api.services"
$iisAppPoolName = "Query.v1"
$iisAppPoolDotNetVersion = "v4.0"
$iisAppPath = "v1\"
$iisAppName = "Query"
$directoryPath = "D:\inetpub\wwwroot\Siglas\EC\erede.api.services\v1\Query"

If (!(Test-Path $directoryPath)) {
    mkdir $directoryPath
    }

cd IIS:\AppPools\

if (!(Test-Path $iisAppPoolName -pathType container))
{
    $appPool = New-Item $iisAppPoolName
    $appPool | Set-ItemProperty -Name "managedRuntimeVersion" -Value $iisAppPoolDotNetVersion
}

cd IIS:\Sites\

if (Test-Path $iisAppName -pathType container)
{
    return
}

$iisApp = New-Item IIS:\Sites\$iisAppSite\$iisAppPath$iisAppName -physicalPath $directoryPath -type Application
Set-ItemProperty IIS:\Sites\$iisAppSite\$iisAppPath$iisAppName -Name applicationPool -Value $iisAppPoolName